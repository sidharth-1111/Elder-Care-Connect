<?php
session_start();
include 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

function getUser($userId)
{
    global $conn;
    $query = "SELECT * FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

$user = getUser($_SESSION['user_id']);

$userId = $_SESSION['user_id'];

if (isset($_POST['place_order'])) {
    if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
        $_SESSION['error'] = 'Your cart is empty!';
        header('Location: cart.php');
        exit();
    }

    // Initialize total amount
    $totalAmount = 0;

    // Other order details
    $orderStatus = 'pending';
    $deliveryAddress = $_POST['delivery_address'];
    $deliver_boy_id = 3;
    $orderDate = date('Y-m-d H:i:s');
    $deliveryDate = new DateTime();
    $deliveryDate->modify('+48 hours');
    $deliveryDate = $deliveryDate->format('Y-m-d H:i:s');
    $conn->query("SET foreign_key_checks = 0");
    // Insert the order
    $query = "INSERT INTO delivery_orders (customer_id, delivery_boy_id, order_status, delivery_address, total_amount, delivery_date) 
              VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iissds", $userId, $deliver_boy_id, $orderStatus, $deliveryAddress, $totalAmount, $deliveryDate);
    $stmt->execute();
    $conn->query("SET foreign_key_checks = 1");

    $orderId = $stmt->insert_id;
    foreach ($_SESSION['cart'] as $productId => $product) {
        $itemPrice = $product['product_price'];
        $quantity = $product['quantity'];
        $totalPrice = $itemPrice * $quantity;
        $totalAmount += $totalPrice;

        // Insert the items into the delivery_items table
        $query = "INSERT INTO delivery_items (order_id, item_id, quantity) 
                  VALUES (?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("iii", $orderId, $productId, $quantity);
        $stmt->execute();

        $query = "UPDATE items SET quantity = quantity - ? WHERE item_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ii", $quantity, $productId);
        $stmt->execute();
    }

    $query = "UPDATE delivery_orders SET total_amount = ? WHERE order_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("di", $totalAmount, $orderId);
    $stmt->execute();

    unset($_SESSION['cart']);

    header("Location: order_confirmation.php?order_id=" . $orderId);
    exit();
}

$totalPrice = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $product) {
        $totalPrice += $product['product_price'] * $product['quantity'];
    }
}
$_SESSION['total_price'] = $totalPrice;  // Store total price in session

include 'includes/header.php';
include 'includes/navigation.php';
?>

<!-- Checkout form (shipping address, etc.) -->
<div class="checkout-section mt-150 mb-150">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12">
                <form action="checkout.php" method="POST">
                    <div class="form-group">
                        <label for="delivery_address">Delivery Address</label>
                        <textarea name="delivery_address" id="delivery_address" class="form-control"
                            required><?php echo $user['address']; ?></textarea>
                    </div>
                    <div class="form-group">
                        <button type="submit" name="place_order" class="btn btn-primary">Place Order</button>
                    </div>
                </form>
            </div>

            <div class="col-lg-4">
                <div class="order-summary">
                    <h3>Order Summary</h3>
                    <table class="table">
                        <tr>
                            <td>Total Amount</td>
                            <td>₹<?= $_SESSION['total_price'] ?? 0 ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>