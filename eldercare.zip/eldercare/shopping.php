<?php
session_start();
include 'config/db.php';

// Function to get all shop items
function getProducts()
{
	global $conn;
	$sql = "SELECT * FROM items";
	$result = $conn->query($sql);

	return $result->fetch_all(MYSQLI_ASSOC);
}

$products = getProducts();



include 'includes/header.php';
include 'includes/cart-sidebar.php';
include 'includes/navigation.php';
?>

<div class="container mx-auto mt-150 mb-150">
	<div class="section-title">
		<h3 class="text-center">Pick Your Items</h3>
	</div>
	<div class="row mt-80">

		<?php foreach ($products as $product) { ?>
			<div class="col-md-3 mb-3">
				<div class="card shadow-sm rounded">
					<div style="height: 170px;" class="d-flex justify-content-center">
						<img src="<?php echo $product['item_image']; ?>" style="width: 80%;"
							alt="<?php echo $product['item_name']; ?>">
					</div>
					<div class="py-4 px-3 text-center justify-content-center">
						<h3><?php echo $product['item_name']; ?></h3>
						<p> ₹<?php echo $product['price']; ?> <span>Per Kg</span></p>
						<form action="" method="POST">
							<input type="hidden" name="product_id" value="<?php echo $product['item_id']; ?>">
							<input type="hidden" name="product_name" value="<?php echo $product['item_name']; ?>">
							<input type="hidden" name="product_price" value="<?php echo $product['price']; ?>">
							<input type="hidden" name="product_image" value="<?php echo $product['item_image']; ?>"
								alt="<?php echo $product['item_name']; ?>">
							<input type="number" name="quantity" value="<?php echo $product['quantity']; ?>" min="1"
								class="form-control mb-2" hidden required>
							<button type="submit" name="add_to_cart" class="btn-cart">
								<i class="fas fa-shopping-cart"></i> Add to Cart
							</button>
						</form>
					</div>
				</div>
			</div>
			<?php
		}
		?>

	</div>
</div>

<?php
include 'includes/footer.php';
?>