<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/config.php';

$email_error = "";
$password_error = "";
$email = "";
$password = "";
$error_msg = "";


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($email)) {
        $email_error = "Email is required.";
    }

    if (empty($password)) {
        $password_error = "Password is required.";
    }

    if (empty($email_error) && empty($password_error)) {
        global $conn;

        $sql = "SELECT users.*, roles.role_name, roles.description FROM users
                LEFT JOIN roles ON users.role_id = roles.role_id
                WHERE users.email = ?";

        $stmt = $conn->prepare($sql);

        $stmt->bind_param("s", $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['role_name'] = $user['role_name'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['phone'] = $user['phone_number'];
            $_SESSION['pic'] = $user['profile_picture'];

            switch ($user['role_name']) {
                case 'customer':
                    header("Location: /eldercare/");
                    break;
                default:
                    header("Location: /eldercare/dashboard/");
            }
            exit;
        } else {
            $error_msg = "Invalid email or password.";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elder Care</title>

    <link rel="shortcut icon" type="image/png" href="assets/img/favicon.png">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/components/logins/login-9/assets/css/login-9.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/meanmenu.min.css">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="stylesheet" href="assets/css/eldercare.css">
    <script src="<?php echo $baseUrl; ?>/assets/js/toast.js"></script>

    <style>
        .hidden {
            display: none !important;
        }

        .eld {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            position: absolute;
            top: 10px;
        }

        .mt-120 {
            margin-top: 120px;
        }
        
    </style>
</head>

<body style="background-color: #f5f5f5;">
    <div id="eltoast" class="hidden eld">
        <div id="toastClass" class="alert alert-success w-50" role="alert" style="z-index: 99999">
            <strong id="eltoastmessage">Holy guacamole!</strong>
            <button type="button" class="close" id="toast-close-btn">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>

    <?php if (!empty($_SESSION['message'])): ?>
        <script>
            showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
        </script>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <div class="max-w-lg mx-auto">
        <div class="d-flex align-items-center justify-content-center" style="height: 100vh;">
            <div class="login-wrap p-5 p-md-5 shadow-sm" style="background-color: #ffffff; width: 500px;">
                <div class="d-flex">
                    <div class="w-100">
                        <h4 class="text-center font-weight-bolder" style="color: #3b82f6;">Welcome Back !</h4>
                        <h5 class="font-weight-normal mb-4 text-center">Sign in to continue to ElderCare.</h5>
                    </div>
                </div>
                <form action="login.php" class="signin-form" method="POST">
                    <?php if (!empty($error_msg)): ?>
                        <p class="mt-2 text-danger text-center"><?= htmlspecialchars($error_msg) ?></p>
                    <?php endif; ?>
                    <div class="form-group mb-3">
                        <label class="label" for="name">Email</label>
                        <input type="email" name="email" value="<?= htmlspecialchars($email) ?>"
                            class="form-control <?php echo !empty($email_error) ? 'is-invalid' : '' ?>" id="email"
                            placeholder="Email" required="">
                        <?php if (!empty($email_error)): ?>
                            <div class="invalid-feedback"><?= htmlspecialchars($email_error) ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group mb-3">
                        <label class="label" for="password">Password</label>
                        <input type="password" name="password"
                            class="form-control <?= !empty($password_error) ? 'is-invalid' : '' ?>"
                            placeholder="Password" required="">
                        <?php if (!empty($password_error)): ?>
                            <div class="invalid-feedback"><?= htmlspecialchars($password_error) ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="form-control btn btn-primary rounded submit px-3">Sign In</button>
                    </div>
                    <div class="form-group d-md-flex">
                        
                    </div>
                </form>
                <p class="text-center">Not a member? <a data-toggle="tab" href="/eldercare/register.php">Sign Up</a></p>
            </div>
        </div>
    </div>

</body>

</html>