<?php 

function addToCart($productId, $productName, $productPrice, $quantity, $productImage)
{
	if (!isset($_SESSION['cart'])) {
		$_SESSION['cart'] = array();
	}

	if (isset($_SESSION['cart'][$productId])) {
		$_SESSION['cart'][$productId]['quantity'] += $quantity;
	} else {
		$_SESSION['cart'][$productId] = array(
			'product_name' => $productName,
			'product_price' => $productPrice,
			'quantity' => $quantity,
			'product_image' => $productImage
		);
	}

}

function updateCart($action, $productId)
{
	if (!isset($_SESSION['cart']) || !isset($_SESSION['cart'][$productId])) {
		return;
	}

	$item = &$_SESSION['cart'][$productId];
	if (strpos($action, 'increase') !== false) {
		$item['quantity']++;
	} elseif (strpos($action, 'decrease') !== false) {
		if ($item['quantity'] > 1) {
			$item['quantity']--;
		}
	} elseif (strpos($action, 'remove') !== false) {
		unset($_SESSION['cart'][$productId]);
	}
}

if (isset($_POST['update_cart'])) {
	$action = $_POST['update_cart'];

	$productId = explode('_', $action)[1];
	updateCart($action, $productId);

	$currentPage = $_SERVER['REQUEST_URI'];
    header("Location: $currentPage");
    exit();
}


if (isset($_POST['add_to_cart'])) {
	$productId = $_POST['product_id'];
	$productName = $_POST['product_name'];
	$productPrice = $_POST['product_price'];
	$quantity = 1;
	$productImage = $_POST['product_image']; 

	addToCart($productId, $productName, $productPrice, $quantity, $productImage);

    $currentPage = $_SERVER['REQUEST_URI'];
    header("Location: $currentPage");
    exit();
}

?>

<div id="cart-sidebar" class="d-none">
    <button id="close-cart-sidebar" class="close-btn">&times;</button>

    <h4>Your Cart</h4>
    <hr>
    <a href="/eldercare/cart.php" class="btn btn-primary">View Cart</a>
    <?php
    if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])):
        $totalAmount = 0;
        foreach ($_SESSION['cart'] as $productId => $item):
            $totalAmount += $item['product_price'] * $item['quantity'];
            ?>
            <div class="cart-item">
                <img src="<?= $item['product_image'] ?>" alt="<?= $item['product_name'] ?>">
                <div class="item-info">
                    <h4><?= $item['product_name'] ?></h4>
                    <p>Price: $<?= number_format($item['product_price'], 2) ?></p>
                    <p class="quantity">Quantity: <?= $item['quantity'] ?></p>

                    <!-- Action Buttons -->
                    <form method="POST" class="action-buttons">
                        <!-- Increase Quantity -->
                        <button type="submit" name="update_cart" value="increase_<?= $productId ?>"
                            class="btn btn-sm btn-info">+</button>
                        <!-- Decrease Quantity -->
                        <button type="submit" name="update_cart" value="decrease_<?= $productId ?>"
                            class="btn btn-sm btn-warning">-</button>
                        <!-- Remove Item -->
                        <button type="submit" name="update_cart" value="remove_<?= $productId ?>"
                            class="btn btn-sm btn-danger">x</button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
        <div class="total">
            <p>Total: $<?= number_format($totalAmount, 2) ?></p>
        </div>
    <?php else: ?>
        <p>Your cart is empty.</p>
    <?php endif; ?>
</div>