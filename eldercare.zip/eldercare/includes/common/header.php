<?php
if (isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: /eldercare/login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>/assets/css/style.css">
    <title>Dashboard</title>
    <style>
        
    </style>
    <script src="<?php echo $baseUrl; ?>/assets/js/toast.js"></script>
</head>

<body class="text-gray-800 font-inter antialiased">
    <?php include 'sidebar.php'; ?>
    <?php include 'toast.php'; ?>
    <main class="w-full md:w-[calc(100%-256px)] md:ml-64 bg-gray-50 min-h-screen transition-all main">
        <?php include 'navbar.php'; ?>