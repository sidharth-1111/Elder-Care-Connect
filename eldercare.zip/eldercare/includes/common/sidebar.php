<?php
$currentUrl = $_SERVER['REQUEST_URI'];
$role = $_SESSION['role_name'] ?? '';
?>
<div class="fixed left-0 top-0 w-64 h-full bg-gray-900 p-4 z-50 sidebar-menu transition-transform ">
    <a href="<?php echo $baseUrl; ?>/dashboard/" class="flex items-center pb-4 border-b border-b-gray-800">
        <img src="https://placehold.co/32x32" alt="" class="w-8 h-8 rounded object-cover">
        <span class="text-lg font-bold text-white ml-3">Elderly Care</span>
    </a>
    <ul class="mt-4">
        <!-- <li class="mb-1 group <?php echo $currentUrl == '/eldercare/admin/' ? 'active' : ''; ?>">
            <a href="<?php echo $baseUrl; ?>/dashboard/"
                class="flex items-center py-2 px-4 text-gray-300 hover:bg-gray-950 hover:text-gray-100 rounded-md group-[.active]:bg-gray-800 group-[.active]:text-white group-[.selected]:bg-gray-950 group-[.selected]:text-gray-100">
                <i class="ri-home-2-line mr-3 text-lg"></i>
                <span class="text-sm">Dashboard</span>
            </a>
        </li> -->

        <?php if ($role == 'admin'): ?>
            <li
                class="mb-1 group <?php echo strpos($currentUrl, '/eldercare/dashboard/users/') === 0 ? 'selected' : ''; ?>">
                <a href="#"
                    class="flex items-center py-2 px-4 text-gray-300 hover:bg-gray-950 hover:text-gray-100 rounded-md group-[.active]:bg-gray-800 group-[.active]:text-white group-[.selected]:bg-gray-950 group-[.selected]:text-gray-100 sidebar-dropdown-toggle">
                    <i class="ri-instance-line mr-3 text-lg"></i>
                    <span class="text-sm">Users</span>
                    <i class="ri-arrow-right-s-line ml-auto group-[.selected]:rotate-90"></i>
                </a>
                <ul class="pl-7 mt-2 hidden group-[.selected]:block">
                    <li class="mb-4">
                        <a href="<?php echo $baseUrl; ?>/dashboard/users/"
                            class="<?php echo $currentUrl == '/eldercare/dashboard/users/' ? 'text-white font-bold' : 'text-gray-300'; ?> text-sm flex items-center hover:text-gray-100 before:contents-[''] before:w-1 before:h-1 before:rounded-full before:bg-gray-300 before:mr-3">List
                            users</a>
                    </li>
                    <li class="mb-4">
                        <a href="<?php echo $baseUrl; ?>/dashboard/users/create.php"
                            class="<?php echo $currentUrl == '/eldercare/admin/users/create.php' ? 'text-white font-bold' : 'text-gray-300'; ?> text-sm flex items-center hover:text-gray-100 before:contents-[''] before:w-1 before:h-1 before:rounded-full before:bg-gray-300 before:mr-3">Create
                            user</a>
                    </li>
                </ul>
            </li>
            <li
                class="mb-1 group <?php echo strpos($currentUrl, '/eldercare/dashboard/services/') === 0 ? 'selected' : ''; ?>">
                <a href="#"
                    class="flex items-center py-2 px-4 text-gray-300 hover:bg-gray-950 hover:text-gray-100 rounded-md group-[.active]:bg-gray-800 group-[.active]:text-white group-[.selected]:bg-gray-950 group-[.selected]:text-gray-100 sidebar-dropdown-toggle">
                    <i class="ri-flashlight-line mr-3 text-lg"></i>
                    <span class="text-sm">Services</span>
                    <i class="ri-arrow-right-s-line ml-auto group-[.selected]:rotate-90"></i>
                </a>
                <ul class="pl-7 mt-2 hidden group-[.selected]:block">
                    <li class="mb-4">
                        <a href="<?php echo $baseUrl; ?>/dashboard/services/"
                            class="text-gray-300 text-sm flex items-center hover:text-gray-100 before:contents-[''] before:w-1 before:h-1 before:rounded-full before:bg-gray-300 before:mr-3">Manage
                            services</a>
                    </li>
                    <li class="mb-4">
                        <a href="<?php echo $baseUrl; ?>/dashboard/services/assign-service-role.php"
                            class="text-gray-300 text-sm flex items-center hover:text-gray-100 before:contents-[''] before:w-1 before:h-1 before:rounded-full before:bg-gray-300 before:mr-3">Assign
                            service to role</a>
                    </li>
                </ul>
            </li>
            <li
                class="mb-1 group <?php echo strpos($currentUrl, '/eldercare/dashboard/roles/') === 0 ? 'selected' : ''; ?>">
                <a href="#"
                    class="flex items-center py-2 px-4 text-gray-300 hover:bg-gray-950 hover:text-gray-100 rounded-md group-[.active]:bg-gray-800 group-[.active]:text-white group-[.selected]:bg-gray-950 group-[.selected]:text-gray-100 sidebar-dropdown-toggle">
                    <i class="ri-instance-line mr-3 text-lg"></i>
                    <span class="text-sm">Roles</span>
                    <i class="ri-arrow-right-s-line ml-auto group-[.selected]:rotate-90"></i>
                </a>
                <ul class="pl-7 mt-2 hidden group-[.selected]:block">
                    <li class="mb-4">
                        <a href="<?php echo $baseUrl; ?>/dashboard/roles/"
                            class="text-gray-300 text-sm flex items-center hover:text-gray-100 before:contents-[''] before:w-1 before:h-1 before:rounded-full before:bg-gray-300 before:mr-3">Roles</a>
                    </li>
                    <li class="mb-4">
                        <a href="<?php echo $baseUrl; ?>/dashboard/roles/create.php"
                            class="text-gray-300 text-sm flex items-center hover:text-gray-100 before:contents-[''] before:w-1 before:h-1 before:rounded-full before:bg-gray-300 before:mr-3">Create
                            Role</a>
                    </li>
                </ul>
            </li>
            <li
                class="mb-1 group <?php echo strpos($currentUrl, '/eldercare/dashboard/hospital/') === 0 ? 'selected' : ''; ?>">
                <a href="#"
                    class="flex items-center py-2 px-4 text-gray-300 hover:bg-gray-950 hover:text-gray-100 rounded-md group-[.active]:bg-gray-800 group-[.active]:text-white group-[.selected]:bg-gray-950 group-[.selected]:text-gray-100 sidebar-dropdown-toggle">
                    <i class="ri-instance-line mr-3 text-lg"></i>
                    <span class="text-sm">Hospital</span>
                    <i class="ri-arrow-right-s-line ml-auto group-[.selected]:rotate-90"></i>
                </a>
                <ul class="pl-7 mt-2 hidden group-[.selected]:block">
                    <li class="mb-4">
                        <a href="<?php echo $baseUrl; ?>/dashboard/hospital/"
                            class="text-gray-300 text-sm flex items-center hover:text-gray-100 before:contents-[''] before:w-1 before:h-1 before:rounded-full before:bg-gray-300 before:mr-3">List
                            Hospitals</a>
                    </li>
                    <li class="mb-4">
                        <a href="<?php echo $baseUrl; ?>/dashboard/hospital/create.php"
                            class="text-gray-300 text-sm flex items-center hover:text-gray-100 before:contents-[''] before:w-1 before:h-1 before:rounded-full before:bg-gray-300 before:mr-3">Create
                            Hospital</a>
                    </li>
                    <li class="mb-4">
                        <a href="<?php echo $baseUrl; ?>/dashboard/hospital/assign-doctor-hospital.php"
                            class="text-gray-300 text-sm flex items-center hover:text-gray-100 before:contents-[''] before:w-1 before:h-1 before:rounded-full before:bg-gray-300 before:mr-3">Assign
                            Doctor To Hospital</a>
                    </li>
                </ul>
            </li>
            <li
                class="mb-1 group <?php echo strpos($currentUrl, '/eldercare/dashboard/hospital/') === 0 ? 'selected' : ''; ?>">
                <a href="#"
                    class="flex items-center py-2 px-4 text-gray-300 hover:bg-gray-950 hover:text-gray-100 rounded-md group-[.active]:bg-gray-800 group-[.active]:text-white group-[.selected]:bg-gray-950 group-[.selected]:text-gray-100 sidebar-dropdown-toggle">
                    <i class="ri-instance-line mr-3 text-lg"></i>
                    <span class="text-sm">Cars</span>
                    <i class="ri-arrow-right-s-line ml-auto group-[.selected]:rotate-90"></i>
                </a>
                <ul class="pl-7 mt-2 hidden group-[.selected]:block">
                    <li class="mb-4">
                        <a href="<?php echo $baseUrl; ?>/dashboard/cars/"
                            class="text-gray-300 text-sm flex items-center hover:text-gray-100 before:contents-[''] before:w-1 before:h-1 before:rounded-full before:bg-gray-300 before:mr-3">List
                            Cars</a>
                    </li>
                    <li class="mb-4">
                        <a href="<?php echo $baseUrl; ?>/dashboard/cars/create.php"
                            class="text-gray-300 text-sm flex items-center hover:text-gray-100 before:contents-[''] before:w-1 before:h-1 before:rounded-full before:bg-gray-300 before:mr-3">Create
                            Car</a>
                    </li>
                </ul>
            </li>
            <li
                class="mb-1 group <?php echo strpos($currentUrl, '/eldercare/dashboard/shopping/') === 0 ? 'selected' : ''; ?>">
                <a href="#"
                    class="flex items-center py-2 px-4 text-gray-300 hover:bg-gray-950 hover:text-gray-100 rounded-md group-[.active]:bg-gray-800 group-[.active]:text-white group-[.selected]:bg-gray-950 group-[.selected]:text-gray-100 sidebar-dropdown-toggle">
                    <i class="ri-instance-line mr-3 text-lg"></i>
                    <span class="text-sm">Shopping Items</span>
                    <i class="ri-arrow-right-s-line ml-auto group-[.selected]:rotate-90"></i>
                </a>
                <ul class="pl-7 mt-2 hidden group-[.selected]:block">
                    <li class="mb-4">
                        <a href="<?php echo $baseUrl; ?>/dashboard/shopping/"
                            class="text-gray-300 text-sm flex items-center hover:text-gray-100 before:contents-[''] before:w-1 before:h-1 before:rounded-full before:bg-gray-300 before:mr-3">Manage
                            Shopping Items</a>
                    </li>
                </ul>
            </li>
        <?php endif; ?>

        <?php if ($role == 'customer'): ?>
            <li class="mb-1 group <?php echo $currentUrl == '/eldercare/dashboard/' ? 'active' : ''; ?>">
                <a href="<?php echo $baseUrl; ?>/dashboard/"
                    class="flex items-center py-2 px-4 text-gray-300 hover:bg-gray-950 hover:text-gray-100 rounded-md group-[.active]:bg-gray-800 group-[.active]:text-white group-[.selected]:bg-gray-950 group-[.selected]:text-gray-100">
                    <i class="ri-home-2-line mr-3 text-lg"></i>
                    <span class="text-sm">Your Orders</span>
                </a>
            </li>

            <li class="mb-1 group <?php echo $currentUrl == '/eldercare/dashboard/customers/' ? 'active' : ''; ?>">
                <a href="<?php echo $baseUrl; ?>/dashboard/customers/"
                    class="flex items-center py-2 px-4 text-gray-300 hover:bg-gray-950 hover:text-gray-100 rounded-md group-[.active]:bg-gray-800 group-[.active]:text-white group-[.selected]:bg-gray-950 group-[.selected]:text-gray-100">
                    <i class="ri-home-2-line mr-3 text-lg"></i>
                    <span class="text-sm">Appointments</span>
                </a>
            </li>
            <li
                class="mb-1 group <?php echo $currentUrl == '/eldercare/dashboard/customers/carbooking.php' ? 'active' : ''; ?>">
                <a href="<?php echo $baseUrl; ?>/dashboard/customers/carbooking.php/"
                    class="flex items-center py-2 px-4 text-gray-300 hover:bg-gray-950 hover:text-gray-100 rounded-md group-[.active]:bg-gray-800 group-[.active]:text-white group-[.selected]:bg-gray-950 group-[.selected]:text-gray-100">
                    <i class="ri-home-2-line mr-3 text-lg"></i>
                    <span class="text-sm">Car Bookings</span>
                </a>
            </li>
            <li
                class="mb-1 group <?php echo $currentUrl == '/eldercare/dashboard/customers/home-nurse.php' ? 'active' : ''; ?>">
                <a href="<?php echo $baseUrl; ?>/dashboard/customers/home-nurse.php/"
                    class="flex items-center py-2 px-4 text-gray-300 hover:bg-gray-950 hover:text-gray-100 rounded-md group-[.active]:bg-gray-800 group-[.active]:text-white group-[.selected]:bg-gray-950 group-[.selected]:text-gray-100">
                    <i class="ri-home-2-line mr-3 text-lg"></i>
                    <span class="text-sm">Home Nurse Booking</span>
                </a>
            </li>
        <?php endif; ?>

        <?php if ($role == 'delivery_boy'): ?>
            <li class="mb-1 group <?php echo $currentUrl == '/eldercare/dashboard/' ? 'active' : ''; ?>">
                <a href="<?php echo $baseUrl; ?>/dashboard/"
                    class="flex items-center py-2 px-4 text-gray-300 hover:bg-gray-950 hover:text-gray-100 rounded-md group-[.active]:bg-gray-800 group-[.active]:text-white group-[.selected]:bg-gray-950 group-[.selected]:text-gray-100">
                    <i class="ri-home-2-line mr-3 text-lg"></i>
                    <span class="text-sm">Your Orders</span>
                </a>
            </li>
        <?php endif; ?>

        <?php if ($role == 'driver'): ?>
            <li class="mb-1 group <?php echo $currentUrl == '/eldercare/dashboard/' ? 'active' : ''; ?>">
                <a href="<?php echo $baseUrl; ?>/dashboard/"
                    class="flex items-center py-2 px-4 text-gray-300 hover:bg-gray-950 hover:text-gray-100 rounded-md group-[.active]:bg-gray-800 group-[.active]:text-white group-[.selected]:bg-gray-950 group-[.selected]:text-gray-100">
                    <i class="ri-home-2-line mr-3 text-lg"></i>
                    <span class="text-sm">Bookings</span>
                </a>
            </li>
        <?php endif; ?>

        <?php if ($role == 'doctor'): ?>
            <li class="mb-1 group <?php echo $currentUrl == '/eldercare/dashboard/' ? 'active' : ''; ?>">
                <a href="<?php echo $baseUrl; ?>/dashboard/"
                    class="flex items-center py-2 px-4 text-gray-300 hover:bg-gray-950 hover:text-gray-100 rounded-md group-[.active]:bg-gray-800 group-[.active]:text-white group-[.selected]:bg-gray-950 group-[.selected]:text-gray-100">
                    <i class="ri-home-2-line mr-3 text-lg"></i>
                    <span class="text-sm">Appointments</span>
                </a>
            </li>
        <?php endif; ?>

        <?php if ($role == 'home_nurse'): ?>
            <li class="mb-1 group <?php echo $currentUrl == '/eldercare/dashboard/' ? 'active' : ''; ?>">
                <a href="<?php echo $baseUrl; ?>/dashboard/"
                    class="flex items-center py-2 px-4 text-gray-300 hover:bg-gray-950 hover:text-gray-100 rounded-md group-[.active]:bg-gray-800 group-[.active]:text-white group-[.selected]:bg-gray-950 group-[.selected]:text-gray-100">
                    <i class="ri-home-2-line mr-3 text-lg"></i>
                    <span class="text-sm">Bookings</span>
                </a>
            </li>
        <?php endif; ?>

    </ul>
</div>
<div class="fixed top-0 left-0 w-full h-full bg-black/50 z-40 md:hidden sidebar-overlay"></div>