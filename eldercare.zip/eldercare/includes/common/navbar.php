<div class="py-2 px-6 bg-white flex items-center shadow-md shadow-black/5 sticky top-0 left-0 z-30">
    <button type="button" class="text-lg text-gray-600 sidebar-toggle">
        <i class="ri-menu-line"></i>
    </button>
    <ul class="flex items-center text-sm ml-4">
        <li class="mr-2">
            <a href="#" class="text-gray-400 hover:text-gray-600 font-medium">Dashboard of <?php echo $_SESSION['role_name'] ?></a>

        </li>
    </ul>
    <ul class="ml-auto flex items-center">

        <li class="dropdown ml-3">
            <button type="button" class="dropdown-toggle flex items-center">
                <img src="<?php echo $_SESSION['pic'] ?>" alt=""
                    class="w-8 h-8 rounded block object-cover align-middle">
                <span class="md:block ml-2 text-gray-700 text-[13px] font-medium"><?php echo $_SESSION['name'] ?></span>
            </button>
            <ul
                class="dropdown-menu shadow-md shadow-black/5 z-30 hidden py-1.5 rounded-md bg-white border border-gray-100 w-full max-w-[140px]">
                <li>
                    <a href="<?php echo $baseUrl; ?>/dashboard/profile.php?id=<?php echo $_SESSION['user_id'] ?>"
                        class="flex items-center text-[13px] py-1.5 px-4 text-gray-600 hover:text-blue-500 hover:bg-gray-50">Profile</a>
                </li>
                <li>
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                        <button type="submit" name="logout"
                            class="flex items-center text-[13px] py-1.5 px-4 text-gray-600 hover:text-blue-500 hover:bg-gray-50 w-full">
                            logout
                        </button>
                    </form>
                </li>
            </ul>
        </li>
    </ul>
</div>