<div id="eltoast" class="hidden">
    <div id="toastClass" class="max-w-xs fixed !bg-green-100 border border-green-400 !text-green-700 top-[60px] right-5 text-sm rounded-lg " role="alert"
        tabindex="-1" aria-labelledby="hs-toast-soft-color-teal-label" style="z-index: 99999">
        <div id="hs-toast-soft-color-teal-label" class="flex p-4">
            <div id="eltoastmessage"></div>

            <div class="ms-auto">
                <button id="toast-close-btn" type="button"
                    class="inline-flex shrink-0 justify-center items-center size-5 rounded-lg text-teal-800 opacity-50 hover:opacity-100 focus:outline-none focus:opacity-100 dark:text-teal-200"
                    aria-label="Close">
                    <span class="sr-only">Close</span>
                    <svg class="shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                        viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round">
                        <path d="M18 6 6 18"></path>
                        <path d="m6 6 12 12"></path>
                    </svg>
                </button>
            </div>
        </div>
    </div>
</div>