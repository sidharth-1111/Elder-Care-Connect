<!-- modal.php -->
<div id="dynamicModal" class="fixed inset-0 bg-gray-800 bg-opacity-50 flex justify-center items-center z-50 hidden">
    <div class="bg-white p-6 rounded-lg shadow-lg max-w-sm w-full">
        <!-- Dynamic Title -->
        <p id="modalMessage" class="text-lg font-semibold text-center mb-4"></p>
        <div class="flex justify-around">
            <!-- Yes Button -->
            <button id="modalConfirmBtn" class="bg-green-500 text-white py-2 px-6 rounded-md hover:bg-green-600">Yes</button>
            <!-- No Button -->
            <button id="modalCancelBtn" class="bg-red-500 text-white py-2 px-6 rounded-md hover:bg-red-600">No</button>
        </div>
    </div>
</div>
