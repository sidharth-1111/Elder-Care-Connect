</main>
<script src="https://unpkg.com/@popperjs/core@2"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="<?php echo $baseUrl; ?>/assets/js/app.js"></script>
<script src="<?php echo $baseUrl; ?>/assets/js/modal.js"></script>

</body>

</html>