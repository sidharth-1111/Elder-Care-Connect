<?php
$baseUrl = "http://localhost/eldercare";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Responsive eldercare website">

    <title>Elder Care</title>

    <link rel="shortcut icon" type="image/png" href="assets/img/favicon.png">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/components/logins/login-9/assets/css/login-9.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/meanmenu.min.css">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="stylesheet" href="assets/css/eldercare.css">
    <script src="<?php echo $baseUrl; ?>/assets/js/toast.js"></script>

    <style>
        .hidden {
            display: none !important;
        }

        .eld {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            position: absolute;
            top: 90px;
        }

        .mt-120 {
            margin-top: 120px;
        }
        
    </style>


</head>

<body>
    <?php
    include 'includes/preloader.php';
    ?>

    <div id="eltoast" class="hidden eld">
        <div id="toastClass" class="alert alert-success w-50" role="alert" style="z-index: 99999">
            <strong id="eltoastmessage">Holy guacamole!</strong>
            <button type="button" class="close" id="toast-close-btn">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>

    </div>