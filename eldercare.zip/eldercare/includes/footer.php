<!-- footer -->
<div class="footer-area" style="padding-top: 20px; padding-bottom: 20px;">
    <div class="container">
        <div class="row justify-content-center">
            
            <div class="col-lg-4 col-md-6">
                <div class="footer-box get-in-touch">
                    <h2 class="widget-title">Get in Touch</h2>
                    <ul>
                        <li>34/8, East klm, erk, jewtown.</li>
                        <li>support@eldercare.com</li>
                        <li>+00 111 222 3333</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="footer-box pages">
                    <h2 class="widget-title">Pages</h2>
                    <ul>
                        <li><a href="/eldercare">Home</a></li>
                        <li><a href="/eldercare#services">Services</a></li>
                        <li><a href="/eldercare#about">About</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="footer-box about-widget">
                    <h2 class="widget-title">About us</h2>
                    <p> Empowering seniors to live independently with dignity and ease.
                        From medical support to reliable transportation and shopping assistance,
                        we’re here every step of the way. Compassionate care tailored to your needs.
                        Because your comfort and well-being matter most.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end footer -->


<!-- copyright -->
<div class="copyright">
    <div class="container">
        <div class="row justify-content-center mt-0">
            <div class="col-lg-6 col-md-12">
                <p>Copyrights &copy; 2025 - <a href="https://localhost/eldercare">Elder Care</a>, All Rights
                    Reserved.</p>
            </div>
            
        </div>
    </div>
</div>
<!-- end copyright -->

<!-- jquery -->
<script src="assets/js/jquery-1.11.3.min.js"></script>
<!-- bootstrap -->
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<!-- count down -->
<script src="assets/js/jquery.countdown.js"></script>
<!-- isotope -->
<script src="assets/js/jquery.isotope-3.0.6.min.js"></script>
<!-- waypoints -->
<script src="assets/js/waypoints.js"></script>
<!-- owl carousel -->
<script src="assets/js/owl.carousel.min.js"></script>
<!-- magnific popup -->
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<!-- mean menu -->
<script src="assets/js/jquery.meanmenu.min.js"></script>
<!-- sticker js -->
<script src="assets/js/sticker.js"></script>
<!-- main js -->
<script src="assets/js/main.js"></script>
<script src="assets/js/eldercare.js"></script>
<script>
    // jQuery for activating tabs on load
    $(document).ready(function () {
        $('#myTab a').click(function (e) {
            e.preventDefault();
            $(this).tab('show');
        });
    });
</script>

</body>

</html>