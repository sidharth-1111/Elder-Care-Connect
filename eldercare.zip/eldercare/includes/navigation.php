<!-- header -->

<?php
$currentUrl = $_SERVER['REQUEST_URI'];
?>

<div class="top-header-area py-3" <?php if ($currentUrl !== '/eldercare/') {
    echo 'style="background-color: #000;"';
} ?> id="sticker">
    <div class="container">
        <div>
            <div class="col-lg-12 col-sm-12 text-center">
                <div class="main-menu-wrap d-flex align-items-center justify-content-between">
                    <div class="site-logo">
                        <a href="/eldercare">
                            <h4 class="text-white">
                                ElderCare</h4>
                        </a>
                    </div>
                    <!-- logo -->

                    <!-- menu start -->
                    <nav class="main-menu">
                        <ul class="d-flex align-items-center justify-content-between">
                            <div class="mr-5">
                                <li class="current-list-item"><a href="/eldercare">Home</a></li>
                                <li><a href="/eldercare#services">Services</a></li>
                                <li><a href="/eldercare#about">About</a></li>
                            </div>
                            <div>
                                <li>
                                    <div class="header-icons">
                                        <a class="shopping-cart" style="position: relative" href="/eldercare/cart.php">
                                            <i class="fas fa-shopping-cart"></i>
                                            <span id="cart-item-count" class="item-count">
                                                <?php
                                                $totalItems = 0;
                                                if (isset($_SESSION['cart'])) {
                                                    foreach ($_SESSION['cart'] as $item) {
                                                        $totalItems += $item['quantity'];
                                                    }
                                                }
                                                echo $totalItems > 0 ? $totalItems : '';
                                                ?>
                                            </span>
                                        </a>
                                    </div>
                                </li>
                                <li>
                                    <?php if (isset($_SESSION['user_id'])) { ?>
                                        <div class="header-icons">
                                            <div class="dropdown">
                                                <a class="user-icon dropdown-toggle" href="#" id="userDropdown"
                                                    role="button">
                                                    <i class="fas fa-user"></i>
                                                </a>
                                                <div class="dropdown-menu" aria-labelledby="userDropdown">
                                                    <a class="dropdown-item" style="color: #000;" href="<?php echo $baseUrl; ?>/dashboard/profile.php?id=<?php echo $_SESSION['user_id'] ?>">Profile</a>
                                                    <a class="dropdown-item" style="color: #000;" href="<?php echo $baseUrl; ?>/dashboard/">Dashboard</a>
                                                    <a class="dropdown-item" style="color: #000;" href="logout.php">Logout</a>
                                                </div>
                                            </div>
                                        </div>

                                        <script>
                                            const userDropdown = document.getElementById('userDropdown');
                                            const dropdownMenu = document.querySelector('.dropdown-menu');
                                            userDropdown.addEventListener('click', function (event) {
                                                event.preventDefault();
                                                dropdownMenu.classList.toggle('show');
                                            });

                                            document.addEventListener('click', function (event) {
                                                if (!userDropdown.contains(event.target) && !dropdownMenu.contains(event.target)) {
                                                    dropdownMenu.classList.remove('show');
                                                }
                                            });
                                        </script>

                                    <?php } else { ?>
                                        <div class="header-icons">
                                            <a class="user-icon" href="login.php">
                                                Login
                                            </a>
                                        </div>
                                    <?php } ?>
                                </li>
                            </div>
                        </ul>
                    </nav>
                
                    <!-- menu end -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end header -->