<?php
session_start();
include 'config/db.php';
$currentPage = $_SERVER['REQUEST_URI'];

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

function getAllAvailableCars()
{
    global $conn;

    $sql = "SELECT 
        cars.car_id,
        cars.car_name,
        cars.car_model,
        cars.car_image,
        cars.price,
        cars.availability,
        users.user_id AS driver_id,
        users.name AS driver_name,
        users.email AS driver_email,
        users.phone_number AS driver_phone,
        users.address AS driver_address,
        users.profile_picture AS driver_profile_picture
    FROM cars
    JOIN users ON cars.driver_id = users.user_id";

    $result = $conn->query($sql);
    if (!$result) {
        die('Error executing query: ' . $conn->error);
    }

    return $result->fetch_all(MYSQLI_ASSOC);
}

$cars = getAllAvailableCars();


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $validation_success = true;
    $error_messages = [];

    $car_id = isset($_POST['car_id']) ? $_POST['car_id'] : null;
    $customer_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    $driver_id = isset($_POST['driver_id']) ? $_POST['driver_id'] : null;
    $pickup_location = isset($_POST['pickup_location']) ? trim($_POST['pickup_location']) : '';
    $pickup_time = isset($_POST['pickup_time']) ? $_POST['pickup_time'] : '';
    $dropoff_location = isset($_POST['dropoff_location']) ? trim($_POST['dropoff_location']) : '';

    if (!filter_var($driver_id, FILTER_VALIDATE_INT)) {
        $validation_success = false;
        $error_messages[] = "Invalid driver ID.";
    }

    if (empty($pickup_location)) {
        $validation_success = false;
        $error_messages[] = "Pickup location is required.";
    }
    if (empty($dropoff_location)) {
        $validation_success = false;
        $error_messages[] = "Dropoff location is required.";
    }

    $pickup_time_format = 'Y-m-d\TH:i';
    $dt = DateTime::createFromFormat($pickup_time_format, $pickup_time);
    if (!$dt || $dt->format($pickup_time_format) !== $pickup_time) {
        $validation_success = false;
        $error_messages[] = "Pickup time is invalid. Please use the format 'Y-m-d H:i'.";
    }

    if (!$validation_success) {
        $_SESSION['toast_message'] = implode("<br>", $error_messages);
        $_SESSION['toast_type'] = 'error';
        header("Location: $currentPage");
        exit;
    }

    $query = "INSERT INTO driver_bookings (customer_id, driver_id, pickup_location, pickup_time, dropoff_location, booking_status, booking_date)
              VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $booking_status = 'Pending';
    $booking_date = date('Y-m-d H:i:s');
    $stmt->bind_param('iisssss', $customer_id, $driver_id, $pickup_location, $pickup_time, $dropoff_location, $booking_status, $booking_date);

    if ($stmt->execute()) {
        $updateCarQuery = "UPDATE cars SET availability = 0 WHERE driver_id = ? AND availability = 1 LIMIT 1";
        $updateCarStmt = $conn->prepare($updateCarQuery);
        $updateCarStmt->bind_param('i', $driver_id);

        if ($updateCarStmt->execute()) {
            $_SESSION['toast_message'] = "Successfully Booked!";
        } else {
            $_SESSION['toast_message'] = " Error updating car availability: " . $updateCarStmt->error;
        }



    } else {
        $_SESSION['toast_message'] = "Error: " . $stmt->error;
    }

    $stmt->close();
    header("Location: $currentPage");
    exit;
}


include 'includes/header.php';
include 'includes/navigation.php';
include 'includes/cart-sidebar.php';
?>


<div class="container mx-auto mt-120 mb-150">

    <?php if (!empty($_SESSION['toast_message'])): ?>
        <script>
            showToast('<?php echo htmlspecialchars($_SESSION['toast_message']) ?>');
        </script>
        <?php unset($_SESSION['toast_message']); ?>
    <?php endif; ?>

    <div class="section-title">
        <h3 class="text-center">Book your trip</h3>
    </div>
    <div class="row mt-80">

        <?php foreach ($cars as $car) { ?>
            <div class="col-md-3 mb-3">
                <div class="card shadow-sm rounded">
                    <div style="height: 170px;" class="d-flex justify-content-center">
                        <img src="<?php echo $car['car_image']; ?>" style="width: 80%;"
                            alt="<?php echo $car['car_name']; ?>">
                    </div>
                    <div class="py-4 px-3 text-center justify-content-center">
                        <h3><?php echo $car['car_name']; ?></h3>
                        <p> ₹<?php echo $car['price']; ?> <span>Per KL</span></p>
                        <button <?php echo $car['availability'] == 0 ? 'disabled' : ''; ?> type="button" class="btn-cart"
                            <?php echo $car['availability'] == 0 ? 'style="cursor: not-allowed; opacity: 0.5;"' : ''; ?>
                            data-toggle="modal" data-target="#bookingModal" data-carname="<?php echo $car['car_name']; ?>"
                            data-price="<?php echo $car['price']; ?>" data-carid="<?php echo $car['car_id']; ?>"
                            data-driverid="<?php echo $car['driver_id']; ?>"
                            data-drivername="<?php echo $car['driver_name']; ?>">Book Now
                        </button>
                    </div>
                </div>
            </div>
        <?php } ?>


    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="bookingModal" tabindex="-1" role="dialog" aria-labelledby="bookingModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="bookingModalLabel">Car Booking</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Booking Form -->
                <form id="bookingForm" method="POST">
                    <input type="hidden" name="car_id" id="car_id">
                    <input type="hidden" name="driver_id" id="driver_id">
                    <div class="form-group">
                        <label for="pickup_location">Pickup Location</label>
                        <input type="text" class="form-control" name="pickup_location" id="pickup_location" required>
                    </div>
                    <div class="form-group">
                        <label for="pickup_time">Pickup Time</label>
                        <input type="datetime-local" class="form-control" name="pickup_time" id="pickup_time" required>
                    </div>
                    <div class="form-group">
                        <label for="dropoff_location">Dropoff Location</label>
                        <input type="text" class="form-control" name="dropoff_location" id="dropoff_location" required>
                    </div>
                    <div class="form-group">
                        <label for="driver_name">Driver Name</label>
                        <input type="text" disabled class="form-control" name="driver_name" id="driver_name" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Book Now</button>
                </form>
            </div>
        </div>
    </div>
</div>



<?php
include 'includes/footer.php';
?>