<?php
session_start();
include 'config/db.php';

// Handle cart updates (e.g., quantity change)
if (isset($_POST['update_cart'])) {
    $productId = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    if ($quantity > 0) {
        $_SESSION['cart'][$productId]['quantity'] = $quantity;
    } else {
        unset($_SESSION['cart'][$productId]);
    }
    header('Location: cart.php');
    exit();
}

// Handle removing an item from the cart
if (isset($_GET['remove'])) {
    $productId = $_GET['remove'];
    unset($_SESSION['cart'][$productId]);
    header('Location: cart.php');
    exit();
}


include 'includes/header.php';
include 'includes/cart-sidebar.php';
include 'includes/navigation.php';
?>

<div class="cart-section mt-150 mb-150">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12">
                <div class="cart-table-wrap">
                    <table class="cart-table">
                        <thead class="cart-table-head">
                            <tr class="table-head-row">
                                <th class="product-remove">Remove</th>
                                <th class="product-image">Product Image</th>
                                <th class="product-name">Name</th>
                                <th class="product-price">Price</th>
                                <th class="product-quantity">Quantity</th>
                                <th class="product-total">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])):
                                $totalPrice = 0;
                                foreach ($_SESSION['cart'] as $productId => $product):
                                    $total = $product['product_price'] * $product['quantity'];
                                    $totalPrice += $total;
                                    ?>
                                    <tr class="table-body-row">
                                        <td class="product-remove">
                                            <a href="cart.php?remove=<?= $productId ?>"><i class="far fa-window-close"></i></a>
                                        </td>
                                        <td class="product-image">
                                            <img src="<?= $product['product_image'] ?>" alt="<?= $product['product_name'] ?>">
                                        </td>
                                        <td class="product-name"><?= $product['product_name'] ?></td>
                                        <td class="product-price">₹<?= $product['product_price'] ?></td>
                                        <td class="product-quantity px-3">
                                            <form action="cart.php" class="d-flex" method="POST">
                                                <input type="number" name="quantity" value="<?= $product['quantity'] ?>" min="1"
                                                    class="form-control" required>
                                                <input type="hidden" name="product_id" value="<?= $productId ?>">
                                                <button type="submit" name="update_cart"
                                                    class="btn btn-sm btn-primary">Update</button>
                                            </form>
                                        </td>
                                        <td class="product-total">₹<?= $total ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6">Your cart is empty.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="total-section">
                    <table class="total-table">
                        <thead class="total-table-head">
                            <tr class="table-total-row">
                                <th>Total</th>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <tbody>

                            <tr class="total-data">
                                <td><strong>Total: </strong></td>
                                <td>₹<?= $totalPrice ?? 0 ?></td> <!-- Total with shipping -->
                            </tr>
                        </tbody>
                    </table>
                    <div class="cart-buttons">
                        <a href="checkout.php" class="boxed-btn black">Check Out</a>
                    </div>
                </div>

                <!-- <div class="coupon-section">
                    <h3>Apply Coupon</h3>
                    <div class="coupon-form-wrap">
                        <form action="cart.php" method="POST">
                            <p><input type="text" name="coupon_code" placeholder="Coupon"></p>
                            <p><input type="submit" name="apply_coupon" value="Apply"></p>
                        </form>
                    </div>
                </div> -->
            </div>
        </div>
    </div>
</div>


<?php
include 'includes/footer.php';
?>