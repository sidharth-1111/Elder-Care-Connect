<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: /eldercare/login.php");
}
?>

<?php if (isset($_SESSION['role_name']) && $_SESSION['role_name'] == 'admin') {
    include 'admin.php';
} ?>

<?php if (isset($_SESSION['role_name']) && $_SESSION['role_name'] == 'driver') { ?>
    <div>
       <?php include 'driver.php'; ?>
    </div>
<?php } ?>

<?php if (isset($_SESSION['role_name']) && $_SESSION['role_name'] == 'doctor') {
    include 'doctor.php';
} ?>

<?php if (isset($_SESSION['role_name']) && $_SESSION['role_name'] == 'delivery_boy') {
    include 'delivery_boy.php';
} ?>

<?php if (isset($_SESSION['role_name']) && $_SESSION['role_name'] == 'customer') {
    include 'customer.php';
} ?>

<?php if (isset($_SESSION['role_name']) && $_SESSION['role_name'] == 'home_nurse') {
    include 'nurse.php';
} ?>


<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/footer.php';
?>