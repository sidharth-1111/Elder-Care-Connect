<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/config.php';

if (!isset($_SESSION['role_name']) && $_SESSION['role_name'] != 'admin') {
    header("Location: /eldercare/login.php");
}


function getUsers()
{
    global $conn;
    $sql = "SELECT users.*, roles.role_name, roles.description 
        FROM users 
        LEFT JOIN roles ON users.role_id = roles.role_id";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

$users = getUsers();

if (isset($_POST['delete_user']) && isset($_POST['user_id'])) {
    $userId = intval($_POST['user_id']);
    $sql = "DELETE FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $userId);

    if ($stmt->execute()) {
        $stmt->close();
        $_SESSION['message'] = "User deleted successfully!";
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        echo 'Error deleting user.';
    }
}
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/header.php';
?>


<div class="p-6">
    <?php if (!empty($_SESSION['message'])): ?>
        <script>
            showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
        </script>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>
    <div class="bg-white border border-gray-100 shadow-md shadow-black/5 p-6 rounded-md">
        <div class="flex justify-between mb-4 items-start">
            <div class="font-medium">Manage Users</div>
            <div class="dropdown">
                <a href="create.php"
                    class="flex items-center text-[13px] py-1.5 px-4 text-white bg-blue-700  hover:bg-blue-600 rounded shadow">Create
                    user</a>
            </div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full min-w-[540px] table-auto">
                <thead>
                    <tr>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Name
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Email
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Role
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Status
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody class="text-sm text-gray-600">
                    <?php foreach ($users as $user) { ?>
                        <tr class="border-b border-gray-100 hover:bg-gray-50">
                            <td class="py-4 px-4 flex items-center space-x-3">
                                <img src="<?php echo $user['profile_picture'] ?> " alt=""
                                    class="w-8 h-8 rounded-full object-cover">
                                <a href="#"
                                    class="text-blue-600 font-medium hover:text-blue-500 truncate"><?php echo htmlspecialchars($user['name']) ?></a>
                            </td>
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($user['email']) ?></td>
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($user['role_name'] ?? 'N/A') ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500"><?php echo $user['is_active'] ? 'Yes' : 'No' ?></td>
                            <td class="py-4 px-4">
                                <div class="flex space-x-3">
                                    <a href="edit.php?id=<?php echo $user['user_id']; ?>"
                                        class="text-gray-600 hover:text-blue-500 transition duration-300">
                                        <i class="ri-edit-2-line text-lg"></i>
                                    </a>
                                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST"
                                        onsubmit="return confirm('Are you sure you want to delete this user?');">
                                        <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                                        <button type="submit" name="delete_user"
                                            class="text-gray-600 hover:text-red-500 transition duration-300">
                                            <i class="ri-delete-bin-2-line text-lg"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/footer.php';
?>