<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/config.php';

$name_error = "";
$email_error = "";
$password_error = "";
$role_error = "";
$name = "";
$email = "";
$password = "";
$role_id = "";
$phone_number = "";
$address = "";
$profile_picture = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $role_id = $_POST['role_id'] ?? '';
    $phone_number = $_POST['phone_number'] ?? '';
    $address = $_POST['address'] ?? '';

    if (empty($name)) {
        $name_error = "Name is required.";
    }

    if (empty($email)) {
        $email_error = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $email_error = "Invalid email format.";
    }

    if (empty($password)) {
        $password_error = "Password is required.";
    }

    if (empty($role_id)) {
        $role_error = "Role is required.";
    }

    if (empty($name_error) && empty($email_error) && empty($password_error) && empty($role_error)) {
        global $conn;
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, role_id, phone_number, address, profile_picture) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssisss", $name, $email, $hashed_password, $role_id, $phone_number, $address, $profile_picture);

        if ($stmt->execute()) {
            $_SESSION['message'] = "User created successfully!";
            header("Location: " . $baseUrl . '/dashboard/users/create.php');
            exit;
        } else {
            $message = "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}

include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/header.php';
?>

<div class="p-6 max-w-4xl mx-auto">
    <div class="bg-white border border-gray-100 shadow p-6 rounded-md">
        <h2 class="text-2xl font-semibold text-gray-800 mb-6">Create User</h2>

        <?php if (!empty($_SESSION['message'])): ?>
            <script>
                showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
            </script>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <form id="userForm" method="POST" action="">
            <div class="flex flex-col gap-5">
                <div class="mb-4">
                    <label for="name" class="block text-sm font-medium text-gray-700">Name</label>
                    <input type="text"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 <?= !empty($name_error) ? 'border-red-500' : '' ?>"
                        id="name" name="name" value="<?= htmlspecialchars($name) ?>">

                    <?php if (!empty($name_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($name_error) ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-4">
                    <label for="email" class="block text-sm font-medium text-gray-700">Email</label>
                    <input type="email"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 <?= !empty($email_error) ? 'border-red-500' : '' ?>"
                        id="email" name="email" value="<?= htmlspecialchars($email) ?>">

                    <?php if (!empty($email_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($email_error) ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-4">
                    <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
                    <input type="password"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 <?= !empty($password_error) ? 'border-red-500' : '' ?>"
                        id="password" name="password">

                    <?php if (!empty($password_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($password_error) ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-4">
                    <label for="role_id" class="block text-sm font-medium text-gray-700">Role</label>
                    <select id="role_id" name="role_id"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 <?= !empty($role_error) ? 'border-red-500' : '' ?>">
                        <option value="">Select Role</option>
                        <?php
                        $roles = $conn->query("SELECT role_id, role_name FROM roles")->fetch_all(MYSQLI_ASSOC);
                        foreach ($roles as $role): ?>
                            <option value="<?= $role['role_id'] ?>" <?= $role_id == $role['role_id'] ? 'selected' : '' ?>><?= htmlspecialchars($role['role_name']) ?></option>
                        <?php endforeach; ?>
                    </select>

                    <?php if (!empty($role_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($role_error) ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-4">
                    <label for="phone_number" class="block text-sm font-medium text-gray-700">Phone Number</label>
                    <input type="text"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
                        id="phone_number" name="phone_number" value="<?= htmlspecialchars($phone_number) ?>">
                </div>

                <div class="mb-4">
                    <label for="address" class="block text-sm font-medium text-gray-700">Address</label>
                    <textarea id="address" name="address" rows="3"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"><?= htmlspecialchars($address) ?></textarea>
                </div>
            </div>

            <div class="mt-6">
                <button type="submit"
                    class="w-full md:w-auto px-6 py-3 text-white bg-blue-600 rounded-md shadow-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50">
                    Create User
                </button>
            </div>
        </form>
    </div>
</div>

<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/footer.php';
?>
