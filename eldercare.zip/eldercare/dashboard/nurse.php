<?php

if (!isset($_SESSION['user_id'])) {
    header("Location: /eldercare/login.php");
}

function getBookings()
{
    global $conn;
    $sql = "SELECT 
                hnb.home_nurse_booking_id,
                hnb.booking_status,
                hnb.booking_date,
                hnb.service_address,
                u.user_id AS customer_id,
                u.name AS customer_name,
                u.phone_number AS customer_phone,
                u.address AS customer_address
            FROM 
                home_nurse_bookings hnb
            JOIN 
                users u ON hnb.customer_id = u.user_id
            WHERE 
                hnb.home_nurse_id = $_SESSION[user_id]
            ORDER BY 
                hnb.booking_date DESC;";
    
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

$bookings = getBookings();

include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/header.php';
?>

<div class="p-6">
    <?php if (!empty($_SESSION['message'])): ?>
        <script>
            showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
        </script>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>
    <div class="bg-white border border-gray-100 shadow-md shadow-black/5 p-6 rounded-md">
        <div class="flex justify-between mb-4 items-start">
            <div class="font-medium">Bookings</div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full min-w-[540px] table-auto">
                <thead>
                    <tr>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                           Customer Name
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Customer Phone
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Customer Address
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Appointment Date
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Status
                        </th>
                    </tr>
                </thead>
                <tbody class="text-sm text-gray-600">
                    <?php foreach ($bookings as $booking) { ?>
                        <tr class="border-b border-gray-100 hover:bg-gray-50">
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($booking['customer_name']) ?></td>
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($booking['customer_phone']) ?></td>
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($booking['customer_address']) ?></td>
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($booking['booking_date']) ?></td>
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($booking['booking_status']) ?></td>     
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>