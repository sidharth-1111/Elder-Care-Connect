<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/config.php';


if (isset($_POST['delete_service_role']) && isset($_POST['role_service_id'])) {
    $roleServiceId = intval($_POST['role_service_id']);

    $sql = "DELETE FROM role_services WHERE role_service_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $roleServiceId);

    if ($stmt->execute()) {
        $stmt->close();
        $_SESSION['message'] = "Role Service deleted successfully!";
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        echo 'Error deleting role service.';
    }
}


function getServices()
{
    global $conn;
    $sql = "SELECT * FROM services";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

$services = getServices();

function getRoles()
{
    global $conn;
    $sql = "SELECT * FROM roles WHERE role_id != 1 AND role_id != 2";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

$roles = getRoles();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role_id = $_POST['role_id'];
    $service_id = $_POST['service_id'];

    $sql = "INSERT INTO role_services (role_id, service_id) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $role_id, $service_id);

    $role_name = $conn->query("SELECT role_name FROM roles WHERE role_id = $role_id")->fetch_assoc()['role_name'];
    $service_name = $conn->query("SELECT service_name FROM services WHERE service_id = $service_id")->fetch_assoc()['service_name'];

    if ($stmt->execute()) {
        $_SESSION['message'] = "Successfully assigned Service " . $service_name. " to role " . $role_name;
        header("Location: " . $baseUrl . '/dashboard/services/assign-service-role.php/');
        exit;
    } else {
        $message = "Error: " . $stmt->error;
    }

    $stmt->close();
}

function getRoleServices()
{
    global $conn;
    $sql = "SELECT r.role_name, s.service_name, rs.role_service_id
            FROM role_services rs
            JOIN roles r ON rs.role_id = r.role_id
            JOIN services s ON rs.service_id = s.service_id
            ORDER BY r.role_name, s.service_name";

    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

$roleServices = getRoleServices();

include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/header.php';
?>

<div class="p-6 max-w-4xl mx-auto">
    <div class="bg-white border border-gray-100 shadow p-6 rounded-md">
        <h2 class="text-2xl font-semibold text-gray-800 mb-6">Assign Service to Role</h2>

        <?php if (!empty($_SESSION['message'])): ?>
            <script>
                showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
            </script>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <form id="serviceroleForm" method="POST" action="">
            <div class="flex flex-col gap-5">
                <div class="mb-4">
                    <label for="service_id" class="block text-sm font-medium text-gray-700">Service</label>
                    <select id="service_id" name="service_id"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-300 ease-in-out"
                        required>
                        <?php foreach ($services as $service): ?>
                            <option value="<?= $service['service_id'] ?>"><?= $service['service_name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-4">
                    <label for="role_id" class="block text-sm font-medium text-gray-700">Role</label>
                    <select id="role_id" name="role_id"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-300 ease-in-out"
                        required>
                        <?php foreach ($roles as $role): ?>
                            <option value="<?= $role['role_id'] ?>"><?= $role['role_name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="mt-6">
                <button type="submit"
                    class="w-full md:w-auto px-6 py-3 text-white bg-blue-600 rounded-md shadow-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50">
                    Assign
                </button>
            </div>
        </form>
    </div>

    <?php if (!empty($roleServices)): ?>
    <div class="bg-white border border-gray-100 shadow-md shadow-black/5 p-6 rounded-md mt-5">
        <div class="flex justify-between mb-4 items-start">
            <div class="font-medium">Assigned Services</div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full min-w-[540px] table-auto">
                <thead>
                    <tr>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            #</th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Service Name
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Role Name
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody class="text-sm text-gray-600">
                    <?php foreach ($roleServices as $index => $data) { ?>
                        <tr class="border-b border-gray-100 hover:bg-gray-50">
                            <td class="py-4 px-4 text-gray-500"><?php echo $index + 1; ?></td>
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($data['service_name']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($data['role_name']) ?>
                            </td>
                            <td class="py-4 px-4">
                                <div class="flex space-x-3">
                                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST"
                                        onsubmit="return confirm('Are you sure you want to delete this service?');">
                                        <input type="hidden" name="role_service_id"
                                            value="<?php echo $data['role_service_id']; ?>">
                                        <button type="submit" name="delete_service_role"
                                            class="text-gray-600 hover:text-red-500 transition duration-300">
                                            <i class="ri-delete-bin-2-line text-lg"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>

                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>



<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/footer.php';
?>