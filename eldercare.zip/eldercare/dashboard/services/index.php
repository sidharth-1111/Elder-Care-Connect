<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/config.php';

function getServices()
{
    global $conn;
    $sql = "SELECT * FROM services";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

$services = getServices();

if (isset($_POST['delete_service']) && isset($_POST['service_id'])) {
    $serviceId = intval($_POST['service_id']);

    $sql = "DELETE FROM services WHERE service_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $serviceId);

    if ($stmt->execute()) {
        $stmt->close();
        $_SESSION['message'] = "Service deleted successfully!";
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        echo 'Error deleting service.';
    }
}

include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/header.php';
?>


<div class="p-6">
    <?php if (!empty($_SESSION['message'])): ?>
        <script>
            showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
        </script>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <div class="bg-white border border-gray-100 shadow-md shadow-black/5 p-6 rounded-md">
        <div class="flex justify-between mb-4 items-start">
            <div class="font-medium">Manage Services</div>
            <div class="dropdown">
                <a href="create.php"
                    class="flex items-center text-[13px] py-1.5 px-4 text-white bg-blue-700  hover:bg-blue-600 rounded shadow">Create
                    Service</a>
            </div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full min-w-[540px] table-auto">
                <thead>
                    <tr>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            #</th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Service Name
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Description
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody class="text-sm text-gray-600">
                    <?php foreach ($services as $index => $service) { ?>
                        <tr class="border-b border-gray-100 hover:bg-gray-50">
                            <td class="py-4 px-4 text-gray-500"><?php echo $index + 1; ?></td>
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($service['service_name']) ?></td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($service['description'] ?? 'N/A') ?>
                            </td>
                            <td class="py-4 px-4">
                                <div class="flex space-x-3">
                                    <a href="edit.php?id=<?php echo $service['service_id']; ?>"
                                        class="text-gray-600 hover:text-blue-500 transition duration-300">
                                        <i class="ri-edit-2-line text-lg"></i>
                                    </a>
                                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST"
                                        onsubmit="return confirm('Are you sure you want to delete this service?');">
                                        <input type="hidden" name="service_id" value="<?php echo $service['service_id']; ?>">
                                        <button type="submit" name="delete_service"
                                            class="text-gray-600 hover:text-red-500 transition duration-300">
                                            <i class="ri-delete-bin-2-line text-lg"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>

                </tbody>
            </table>
        </div>
    </div>
</div>


<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/footer.php';
?>