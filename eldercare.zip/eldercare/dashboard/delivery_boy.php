<?php
if (!isset($_SESSION['user_id'])) {
    header("Location: /eldercare/login.php");
}

$delivery_boy_id = $_SESSION['user_id'] ?? null;

if (isset($_POST['update_order_status']) && isset($_POST['order_id'])) {
    $orderId = intval($_POST['order_id']);

    $sql = "UPDATE delivery_orders SET order_status = 'dispatched' WHERE order_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $orderId);

    if ($stmt->execute()) {
        $stmt->close();
        $_SESSION['message'] = "Order accepted successfully!";
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        echo 'Error accepting order.';
    }
}


if (isset($_POST['delivered_order_status']) && isset($_POST['order_id'])) {
    $orderId = intval($_POST['order_id']);

    $sql = "UPDATE delivery_orders SET order_status = 'delivered' WHERE order_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $orderId);

    if ($stmt->execute()) {
        $stmt->close();
        $_SESSION['message'] = "Order delivered successfully!";
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        echo 'Error accepting order.';
    }
}



function getOrdersAndUsers()
{
    global $conn;

    // Step 1: Fetch all orders
    $sql_orders = "SELECT * FROM delivery_orders";
    $orders_result = $conn->query($sql_orders);

    if ($orders_result === false) {
        return [];  // Return an empty array if the query fails
    }

    // Step 2: Fetch all users (customers)
    $sql_users = "SELECT * FROM users";
    $users_result = $conn->query($sql_users);

    if ($users_result === false) {
        return [];  // Return an empty array if the query fails
    }

    // Step 3: Create an associative array for users based on user_id
    $users = [];
    while ($user = $users_result->fetch_assoc()) {
        $users[$user['user_id']] = $user;  // Key users by user_id
    }

    // Step 4: Merge orders with user information based on customer_id
    $orders_with_users = [];
    while ($order = $orders_result->fetch_assoc()) {
        $customer_id = $order['customer_id'];

        // Check if we have customer details for this order
        if (isset($users[$customer_id])) {
            // Merge user details with order
            $order['customer_name'] = $users[$customer_id]['name'];
            $order['customer_address'] = $users[$customer_id]['address'];
        } else {
            // If no user found, set customer details as NULL
            $order['customer_name'] = NULL;
            $order['customer_address'] = NULL;
        }

        // Add merged order to the result array
        $orders_with_users[] = $order;
    }

    return $orders_with_users;
}

$orders =  getOrdersAndUsers($delivery_boy_id);

include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/header.php';
?>

<div class="p-6">
    <?php if (!empty($_SESSION['message'])): ?>
        <script>
            showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
        </script>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>
    <div class="bg-white border border-gray-100 shadow-md shadow-black/5 p-6 rounded-md">
        <div class="flex justify-between mb-4 items-start">
            <div class="font-medium">Your Assigned Orders</div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full min-w-[540px] table-auto">
                <thead>
                    <tr>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Order ID
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Customer Name
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Customer Address
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Status
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Total Amount
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Order Date
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Delivery Date
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody class="text-sm text-gray-600">
                    <?php foreach ($orders as $order) { ?>
                        <tr class="border-b border-gray-100 hover:bg-gray-50 <?php if ($order['order_status'] == 'delivered') echo 'bg-green-100'; elseif ($order['order_status'] == 'pending') echo 'bg-yellow-100'; elseif ($order['order_status'] == 'dispatched') echo 'bg-blue-100'; else echo ''; ?>">
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($order['order_id']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($order['customer_name']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($order['customer_address']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($order['order_status']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($order['total_amount']) ?></td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($order['order_date']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($order['delivery_date']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php if ($order['order_status'] == 'pending') { ?>
                                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                                        <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                        <button type="submit" name="update_order_status"
                                            class="text-white bg-green-500 hover:text-green-800 py-1.5 px-3 rounded shadow transition duration-300">Accept
                                        </button>
                                    </form>
                                <?php } ?>

                                <?php if ($order['order_status'] == 'dispatched') { ?>
                                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                                        <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                        <button type="submit" name="delivered_order_status"
                                            class="text-white bg-green-500 hover:text-green-800 py-1.5 px-3 rounded shadow transition duration-300">Delivered
                                        </button>
                                    </form>
                                <?php } ?>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>