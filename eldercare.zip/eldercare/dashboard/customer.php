<?php
if (!isset($_SESSION['user_id'])) {
    header("Location: /eldercare/login.php");
}

$customer_id = $_SESSION['user_id'] ?? null;
function getOrders($customer_id)
{
    global $conn;
    $sql = "
        SELECT 
            delivery_orders.*, 
            users.name AS delivery_boy_name
        FROM 
            delivery_orders 
        JOIN 
            users ON delivery_orders.delivery_boy_id = users.user_id 
        WHERE 
            delivery_orders.customer_id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $customer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

$orders = getOrders($customer_id);


include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/header.php';
?>

<div class="p-6">
    <?php if (!empty($_SESSION['message'])): ?>
        <script>
            showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
        </script>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>
    <div class="bg-white border border-gray-100 shadow-md shadow-black/5 p-6 rounded-md">
        <div class="flex justify-between mb-4 items-start">
            <div class="font-medium">Your Orders</div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full min-w-[540px] table-auto">
                <thead>
                    <tr>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Delivery Boy Name
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Delivery Address
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Status
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Total Amount
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Order Date
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Delivery Date
                        </th>
                    </tr>
                </thead>
                <tbody class="text-sm text-gray-600">
                    <?php foreach ($orders as $order) { ?>
                        <tr class="border-b border-gray-100 hover:bg-gray-50">
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($order['delivery_boy_name']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($order['delivery_address']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($order['order_status']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($order['total_amount']) ?></td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($order['order_date']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($order['delivery_date']) ?>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>