<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/config.php';

$user_id = $_GET['id'] ?? null;
$name_error = "";
$email_error = "";
$password_error = "";
$role_error = "";
$name = "";
$email = "";
$role_id = "";
$phone_number = "";
$address = "";
$profile_picture = "";

if ($user_id) {
    $stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if (!$user) {
        $_SESSION['message'] = "User not found.";
        header("Location: " . $baseUrl . '/dashboard/');
        exit;
    }

    $name = $user['name'];
    $email = $user['email'];
    $role_id = $user['role_id'];
    $phone_number = $user['phone_number'];
    $address = $user['address'];
    $profile_picture = $user['profile_picture'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $role_id = $_POST['role_id'] ?? '';
    $phone_number = $_POST['phone_number'] ?? '';
    $address = $_POST['address'] ?? '';
    $new_profile_picture = $_FILES['profile_picture']['name'] ?? '';

    if (empty($name)) {
        $name_error = "Name is required.";
    }

    if (empty($email)) {
        $email_error = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $email_error = "Invalid email format.";
    }

    if (empty($role_id)) {
        $role_error = "Role is required.";
    }

    if (empty($name_error) && empty($email_error) && empty($role_error)) {
        global $conn;

        if (!empty($new_profile_picture)) {
            $target_dir = $_SERVER['DOCUMENT_ROOT'] . '/eldercare/uploads/';
            $target_file = $target_dir . basename($new_profile_picture);
            move_uploaded_file($_FILES['profile_picture']['tmp_name'], $target_file);
            $profile_picture = '/eldercare/uploads/' . basename($new_profile_picture);
        }

        if (!empty($password)) {
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, password = ?, role_id = ?, phone_number = ?, address = ?, profile_picture = ? WHERE user_id = ?");
            $stmt->bind_param("sssisssi", $name, $email, $hashed_password, $role_id, $phone_number, $address, $profile_picture, $user_id);
        } else {
            $stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, role_id = ?, phone_number = ?, address = ?, profile_picture = ? WHERE user_id = ?");
            $stmt->bind_param("ssisssi", $name, $email, $role_id, $phone_number, $address, $profile_picture, $user_id);
        }

        if ($stmt->execute()) {
            $_SESSION['message'] = "User updated successfully!";
            header("Location: " . $baseUrl . '/dashboard/profile.php?id=' . $user_id . '/');
            exit;
        } else {
            $message = "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}

include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/header.php';
?>

<div class="p-6 max-w-4xl mx-auto">
    <div class="bg-white border border-gray-100 shadow p-6 rounded-md">
        <h2 class="text-2xl font-semibold text-gray-800 mb-6">Profile</h2>

        <?php if (!empty($_SESSION['message'])): ?>
            <script>
                showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
            </script>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <form id="userForm" method="POST" enctype="multipart/form-data" action="">
            <div class="flex flex-col gap-5">
                
                <div class="relative flex justify-center mb-6">
                    <label for="profile_picture" class="cursor-pointer">
                        <img id="profile-img"
                            src="<?= htmlspecialchars($profile_picture) ? htmlspecialchars($profile_picture) : 'default-avatar.jpg' ?>"
                            alt="Profile Picture" class="h-32 w-32 rounded-full border-2 border-gray-300 object-cover">
                        <input type="file" id="profile_picture" name="profile_picture" class="hidden"
                            onchange="previewImage(event)" />
                        <div
                            class="absolute inset-0 flex items-center justify-center bg-opacity-50 opacity-0 hover:opacity-100 transition-opacity">
                            <svg class="w-8 h-8 text-blue-500 bg-white rounded-full text-center" xmlns="http://www.w3.org/2000/svg" fill="none"
                                viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M16 12v.01M12 16l4-4m0 0l-4-4m4 4H3" />
                            </svg>
                        </div>
                    </label>
                </div>

               
                <div class="mb-4">
                    <label for="name" class="text-sm font-medium text-gray-700">Name</label>
                    <input type="text"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 <?= !empty($name_error) ? 'border-red-500' : '' ?>"
                        id="name" name="name" value="<?= htmlspecialchars($name) ?>">

                    <?php if (!empty($name_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($name_error) ?></p>
                    <?php endif; ?>
                </div>

                <!-- Email Field -->
                <div class="mb-4">
                    <label for="email" class="text-sm font-medium text-gray-700">Email</label>
                    <input type="email"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 <?= !empty($email_error) ? 'border-red-500' : '' ?>"
                        id="email" name="email" value="<?= htmlspecialchars($email) ?>">

                    <?php if (!empty($email_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($email_error) ?></p>
                    <?php endif; ?>
                </div>

                <!-- Password Field -->
                <div class="mb-4">
                    <label for="password" class="text-sm font-medium text-gray-700">Password</label>
                    <input type="password"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
                        id="password" name="password">
                    <p class="mt-2 text-sm text-gray-600">Leave blank to keep the current password.</p>
                </div>

                <!-- Role Field -->
                <!-- <div class="mb-4">
                    <label for="role_id" class="text-sm font-medium text-gray-700">Role</label>
                    <select id="role_id" name="role_id"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 <?= !empty($role_error) ? 'border-red-500' : '' ?>">
                        <option value="">Select Role</option>
                        <?php
                        $roles = $conn->query("SELECT role_id, role_name FROM roles")->fetch_all(MYSQLI_ASSOC);
                        foreach ($roles as $role): ?>
                            <option value="<?= $role['role_id'] ?>" <?= $role_id == $role['role_id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($role['role_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <?php if (!empty($role_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($role_error) ?></p>
                    <?php endif; ?>
                </div> -->

                <!-- Phone Number Field -->
                <div class="mb-4">
                    <label for="phone_number" class="text-sm font-medium text-gray-700">Phone Number</label>
                    <input type="text"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
                        id="phone_number" name="phone_number" value="<?= htmlspecialchars($phone_number) ?>">
                </div>

                <!-- Address Field -->
                <div class="mb-4">
                    <label for="address" class="text-sm font-medium text-gray-700">Address</label>
                    <textarea id="address" name="address" rows="3"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"><?= htmlspecialchars($address) ?></textarea>
                </div>

            </div>

            <!-- Submit Button -->
            <div class="mt-6">
                <button type="submit"
                    class="w-full md:w-auto px-6 py-3 text-white bg-blue-600 rounded-md shadow-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50">
                    Update Profile
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function previewImage(event) {
        const file = event.target.files[0];
        const reader = new FileReader();

        reader.onload = function () {
            const profileImg = document.getElementById('profile-img');
            profileImg.src = reader.result;
        };

        if (file) {
            reader.readAsDataURL(file);
        }
    }
</script>

<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/footer.php';
?>