<?php
if (!isset($_SESSION['user_id'])) {
    header("Location: /eldercare/login.php");
}

$driver_id = $_SESSION['user_id'] ?? null;

if (isset($_POST['update_booking_status']) && isset($_POST['booking_id'])) {
    $bookingId = intval($_POST['booking_id']);
    $sql = "UPDATE driver_bookings SET booking_status = 'accepted' WHERE driver_booking_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $bookingId);

    if ($stmt->execute()) {
        $stmt->close();
        $_SESSION['message'] = "Booking accepted successfully!";
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        echo 'Error accepting booking.';
    }
}

if (isset($_POST['complete_booking_status']) && isset($_POST['booking_id'])) {
    $bookingId = intval($_POST['booking_id']);
    $sql = "UPDATE driver_bookings SET booking_status = 'completed' WHERE driver_booking_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $bookingId);

    if ($stmt->execute()) {
        $sql = "UPDATE cars SET availability = 1 WHERE driver_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $driver_id);
        if ($stmt->execute()) {
            $stmt->close();
            $_SESSION['message'] = "Booking completed successfully!";
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        } else {
            echo 'Error completing booking.';
        }
    } else {
        echo 'Error completing booking.';
    }
}


function getBookings($driver_id)
{
    global $conn;
    $sql = "SELECT 
            db.driver_booking_id, 
            db.pickup_location, 
            db.pickup_time, 
            db.dropoff_location, 
            db.booking_status, 
            db.booking_date, 
            u.name AS customer_name, 
            u.address AS customer_address, 
            u.phone_number AS customer_phone_number
            FROM 
            driver_bookings db
            JOIN 
            users u ON db.customer_id = u.user_id
            WHERE 
            db.driver_id = ?
            ORDER BY db.booking_date DESC";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $driver_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

$bookings = getBookings($driver_id);

include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/header.php';
?>

<div class="p-6">
    <?php if (!empty($_SESSION['message'])): ?>
        <script>
            showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
        </script>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>
    <div class="bg-white border border-gray-100 shadow-md shadow-black/5 p-6 rounded-md">
        <div class="flex justify-between mb-4 items-start">
            <div class="font-medium">Scheduled Bookings</div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full min-w-[540px] table-auto">
                <thead>
                    <tr>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Booking ID
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Customer Name
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Customer Address
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Customer Phone Number
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Status
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Booking Date
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Pickup Time
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody class="text-sm text-gray-600">
                    <?php foreach ($bookings as $booking) { ?>
                        <tr class="border-b border-gray-100 hover:bg-gray-50">
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($booking['driver_booking_id']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($booking['customer_name']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($booking['customer_address']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($booking['customer_phone_number']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($booking['booking_status']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                            <?php echo htmlspecialchars((new DateTime($booking['booking_date']))->format('d-m-Y h:i A')); ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars((new DateTime($booking['pickup_time']))->format('d-m-Y h:i A')); ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php if ($booking['booking_status'] == 'pending') { ?>
                                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                                        <input type="hidden" name="booking_id" value="<?php echo $booking['driver_booking_id']; ?>">
                                        <button type="submit" name="update_booking_status"
                                            class="text-white bg-green-500 hover:text-green-800 py-1.5 px-3 rounded shadow transition duration-300">Accept
                                        </button>
                                    </form>
                                <?php } ?>
                                <?php if ($booking['booking_status'] == 'accepted') { ?>
                                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                                        <input type="hidden" name="booking_id" value="<?php echo $booking['driver_booking_id']; ?>">
                                        <button type="submit" name="complete_booking_status"
                                            class="text-white bg-green-500 hover:text-green-800 py-1.5 px-3 rounded shadow transition duration-300">Completed
                                        </button>
                                    </form>
                                <?php } ?>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>