<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/config.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: /eldercare/login.php");
}

$customer_id = $_SESSION['user_id'] ?? null;

function getBookings($customer_id)
{
    global $conn;
    $sql = "SELECT 
            db.driver_booking_id, 
            db.pickup_location, 
            db.pickup_time, 
            db.dropoff_location, 
            db.booking_status, 
            db.booking_date, 
            u.name AS customer_name, 
            u.address AS customer_address, 
            u.phone_number AS customer_phone_number
            FROM 
            driver_bookings db
            JOIN 
            users u ON db.driver_id = u.user_id
            WHERE 
            db.customer_id = ?
            ORDER BY db.booking_date DESC";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $customer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

$bookings = getBookings($customer_id);

include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/header.php';
?>

<div class="p-6">
    <?php if (!empty($_SESSION['message'])): ?>
        <script>
            showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
        </script>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>
    <div class="bg-white border border-gray-100 shadow-md shadow-black/5 p-6 rounded-md">
        <div class="flex justify-between mb-4 items-start">
            <div class="font-medium">Your Assigned Orders</div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full min-w-[540px] table-auto">
                <thead>
                    <tr>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Driver Name
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                        Driver Address
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Driver Phone Number
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Status
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Booking Date
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Pickup Time
                        </th>
                    </tr>
                </thead>
                <tbody class="text-sm text-gray-600">
                    <?php foreach ($bookings as $booking) { ?>
                        <tr class="border-b border-gray-100 hover:bg-gray-50">
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($booking['customer_name']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($booking['customer_address']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($booking['customer_phone_number']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($booking['booking_status']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($booking['booking_date']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($booking['pickup_time']) ?>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>