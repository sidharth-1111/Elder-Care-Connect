<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: /eldercare/login.php");
}

function getAppointments()
{
    global $conn;
    $sql = "SELECT 
        a.appointment_id, 
        a.appointment_date, 
        a.appointment_time, 
        a.consultation_notes, 
        a.status, 
        c.name AS customer_name, 
        d.name AS doctor_name, 
        h.name AS hospital_name 
    FROM appointments a
    JOIN users c ON a.customer_id = c.user_id
    JOIN users d ON a.doctor_id = d.user_id
    JOIN hospitals h ON a.hospital_id = h.hospital_id
    WHERE a.customer_id = $_SESSION[user_id]";
    
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

$appointments = getAppointments();
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/header.php';
?>

<div class="p-6">
    <?php if (!empty($_SESSION['message'])): ?>
        <script>
            showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
        </script>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>
    <div class="bg-white border border-gray-100 shadow-md shadow-black/5 p-6 rounded-md">
        <div class="flex justify-between mb-4 items-start">
            <div class="font-medium">Appointments</div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full min-w-[540px] table-auto">
                <thead>
                    <tr>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                           Patient Name
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Appointment Date
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Appointment Time
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Status
                        </th>
                    </tr>
                </thead>
                <tbody class="text-sm text-gray-600">
                    <?php foreach ($appointments as $appointment) { ?>
                        <tr class="border-b border-gray-100 hover:bg-gray-50">
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($appointment['doctor_name']) ?></td>
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($appointment['appointment_date']) ?></td>
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($appointment['appointment_time']) ?></td>     
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($appointment['status']) ?></td>     
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>