<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/config.php';

function getHospitals()
{
    global $conn;
    $sql = "SELECT * FROM hospitals";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

$hospitals = getHospitals();

if (isset($_POST['delete_hospital']) && isset($_POST['hospital_id'])) {
    $hospitalId = intval($_POST['hospital_id']);

    $sql = "DELETE FROM hospitals WHERE hospital_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $hospitalId);

    if ($stmt->execute()) {
        $stmt->close();
        $_SESSION['message'] = "Hospital deleted successfully!";
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        echo 'Error deleting hospital.';
    }
}

include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/header.php';
?>


<div class="p-6">
    <?php if (!empty($_SESSION['message'])): ?>
        <script>
            showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
        </script>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <div class="bg-white border border-gray-100 shadow-md shadow-black/5 p-6 rounded-md">
        <div class="flex justify-between mb-4 items-start">
            <div class="font-medium">Manage Hospital</div>
            <div class="dropdown">
                <a href="create.php"
                    class="flex items-center text-[13px] py-1.5 px-4 text-white bg-blue-700  hover:bg-blue-600 rounded shadow">Create
                    Hospital</a>
            </div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full min-w-[540px] table-auto">
                <thead>
                    <tr>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            #</th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Hospital Name
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Address
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Description
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody class="text-sm text-gray-600">
                    <?php foreach ($hospitals as $index => $hospital) { ?>
                        <tr class="border-b border-gray-100 hover:bg-gray-50">
                            <td class="py-4 px-4 text-gray-500"><?php echo $index + 1; ?></td>
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($hospital['name']) ?></td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($hospital['address'] ?? 'N/A') ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($hospital['description'] ?? 'N/A') ?>
                            </td>
                            <td class="py-4 px-4">
                                <div class="flex space-x-3">
                                    <a href="edit.php?id=<?php echo $hospital['hospital_id']; ?>"
                                        class="text-gray-600 hover:text-blue-500 transition duration-300">
                                        <i class="ri-edit-2-line text-lg"></i>
                                    </a>
                                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST"
                                        onsubmit="return confirm('Are you sure you want to delete this hospital?');">
                                        <input type="hidden" name="hospital_id" value="<?php echo $hospital['hospital_id']; ?>">
                                        <button type="submit" name="delete_hospital"
                                            class="text-gray-600 hover:text-red-500 transition duration-300">
                                            <i class="ri-delete-bin-2-line text-lg"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>

                </tbody>
            </table>
        </div>
    </div>
</div>


<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/footer.php';
?>