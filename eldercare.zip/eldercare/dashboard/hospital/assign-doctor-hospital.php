<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/config.php';


if (isset($_POST['delete_doctor_hospital']) && isset($_POST['doctor_hospital_id'])) {
    $doctorHospitalId = intval($_POST['doctor_hospital_id']);

    $sql = "DELETE FROM doctor_hospitals WHERE doctor_hospital_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $doctorHospitalId);

    if ($stmt->execute()) {
        $stmt->close();
        $_SESSION['message'] = "Deleted successfully!";
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        echo 'Error deleting.';
    }
}


function getHospitals()
{
    global $conn;
    $sql = "SELECT * FROM hospitals";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

$hospitals = getHospitals();

function getDoctors()
{
    global $conn;
    $sql = "SELECT u.user_id, u.name
            FROM users u
            JOIN roles r ON u.role_id = r.role_id
            WHERE r.role_name = 'doctor'";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

$doctors = getDoctors();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $doctor_id = $_POST['doctor_id'];
    $hospital_id = $_POST['hospital_id'];

    $sql = "INSERT INTO doctor_hospitals (doctor_id, hospital_id) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $doctor_id, $hospital_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Successfully assigned.";
        header("Location: " . $baseUrl . '/dashboard/hospital/assign-doctor-hospital.php/');
        exit;
    } else {
        $message = "Error: " . $stmt->error;
    }

    $stmt->close();
}

function getDoctorHospitals()
{
    global $conn;
    $sql = "SELECT u.name AS doctor_name, h.name AS hospital_name, uh.doctor_hospital_id
            FROM doctor_hospitals uh
            JOIN users u ON uh.doctor_id = u.user_id
            JOIN hospitals h ON uh.hospital_id = h.hospital_id
            ORDER BY u.name, h.name";

    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

$doctorHospitals = getDoctorHospitals();


include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/header.php';
?>

<div class="p-6 max-w-4xl mx-auto">
    <div class="bg-white border border-gray-100 shadow p-6 rounded-md">
        <h2 class="text-2xl font-semibold text-gray-800 mb-6">Assign Doctor to Hospital</h2>

        <?php if (!empty($_SESSION['message'])): ?>
            <script>
                showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
            </script>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <form id="doctorhospitalForm" method="POST" action="">
            <div class="flex flex-col gap-5">
                <div class="mb-4">
                    <label for="doctor_id" class="block text-sm font-medium text-gray-700">Doctor</label>
                    <select id="doctor_id" name="doctor_id"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-300 ease-in-out"
                        required>
                        <?php foreach ($doctors as $doctor): ?>
                            <option value="<?= $doctor['user_id'] ?>"><?= $doctor['name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-4">
                    <label for="hospital_id" class="block text-sm font-medium text-gray-700">Hospital</label>
                    <select id="hospital_id" name="hospital_id"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-300 ease-in-out"
                        required>
                        <?php foreach ($hospitals as $hospital): ?>
                            <option value="<?= $hospital['hospital_id'] ?>"><?= $hospital['name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="mt-6">
                <button type="submit"
                    class="w-full md:w-auto px-6 py-3 text-white bg-blue-600 rounded-md shadow-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50">
                    Assign
                </button>
            </div>
        </form>
    </div>

    <?php if (!empty($doctorHospitals)): ?>
    <div class="bg-white border border-gray-100 shadow-md shadow-black/5 p-6 rounded-md mt-5">
        <div class="flex justify-between mb-4 items-start">
            <div class="font-medium">Assigned Doctors to Hospitals </div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full min-w-[540px] table-auto">
                <thead>
                    <tr>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            #</th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Hospital Name
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Doctor Name
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody class="text-sm text-gray-600">
                    <?php foreach ($doctorHospitals as $index => $data) { ?>
                        <tr class="border-b border-gray-100 hover:bg-gray-50">
                            <td class="py-4 px-4 text-gray-500"><?php echo $index + 1; ?></td>
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($data['hospital_name']) ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($data['doctor_name']) ?>
                            </td>
                            <td class="py-4 px-4">
                                <div class="flex space-x-3">
                                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST"
                                        onsubmit="return confirm('Are you sure you want to delete this service?');">
                                        <input type="hidden" name="doctor_hospital_id"
                                            value="<?php echo $data['doctor_hospital_id']; ?>">
                                        <button type="submit" name="delete_doctor_hospital"
                                            class="text-gray-600 hover:text-red-500 transition duration-300">
                                            <i class="ri-delete-bin-2-line text-lg"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>

                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>



<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/footer.php';
?>