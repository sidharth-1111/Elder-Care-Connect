<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/config.php';

$item_name = "";
$item_details = "";
$item_image = "";
$quantity = "";
$availability = 1;
$item_category = "";
$price = "";
$item_name_error = "";
$quantity_error = "";
$price_error = "";

$item_id = $_GET['id'] ?? null;

if ($item_id) {
    $sql = "SELECT * FROM items WHERE item_id = ?;";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $item_id);
    $stmt->execute();
    $item = $stmt->get_result()->fetch_assoc();

    if (!$item) {
        $_SESSION['error_message'] = "Item not found.";
        header("Location: " . $baseUrl . '/dashboard/shopping/');
        exit;
    }

    $item_name = $item['item_name'];
    $item_details = $item['item_details'];
    $item_image = $item['item_image'];
    $quantity = $item['quantity'];
    $availability = $item['availability'];
    $item_category = $item['item_category'];
    $price = $item['price'];
    $availability = $item['availability'] == 1 ? "Available" : "Not Available";
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_name = $_POST['item_name'] ?? '';
    $item_details = $_POST['item_details'] ?? '';
    $quantity = $_POST['quantity'] ?? '';
    $availability = $_POST['availability'] ?? 1;
    $price = $_POST['price'] ?? '';
    $new_item_image = $_FILES['item_image']['name'] ?? '';

    if (empty($item_name)) {
        $item_name_error = "Item name is required.";
    }

    if (empty($quantity)) {
        $quantity_error = "Quantity is required.";
    } elseif (!is_numeric($quantity) || $quantity < 0) {
        $quantity_error = "Quantity must be a valid number.";
    }

    if (empty($price)) {
        $price_error = "Price is required.";
    } elseif (!is_numeric($price)) {
        $price_error = "Price must be a valid number.";
    }

    if (empty($item_name_error) && empty($quantity_error) && empty($price_error)) {
        global $conn;

        $item_image_path = $item_image;
        if (!empty($new_item_image)) {
            $target_dir = $_SERVER['DOCUMENT_ROOT'] . '/eldercare/uploads/items/';
            $target_file = $target_dir . basename($new_item_image);
            move_uploaded_file($_FILES['item_image']['tmp_name'], $target_file);
            $item_image_path = '/eldercare/uploads/items/' . basename($new_item_image);
        }

        $stmt = $conn->prepare("UPDATE items SET item_name = ?, item_image = ?, item_details = ?, quantity = ?, availability = ?, price = ? WHERE item_id = ?");
        $stmt->bind_param("sssiiii", $item_name, $item_image_path, $item_details, $quantity, $availability, $price, $item_id);

        if ($stmt->execute()) {
            $_SESSION['message'] = "Item updated successfully!";
            header("Location: " . $baseUrl . '/dashboard/shopping/');
            exit;
        } else {
            $message = "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}


include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/header.php';
?>

<div class="p-6 max-w-4xl mx-auto">
    <div class="bg-white border border-gray-100 shadow p-6 rounded-md">
        <h2 class="text-2xl font-semibold text-gray-800 mb-6">Update Item</h2>

        <?php if (!empty($_SESSION['message'])): ?>
            <script>
                showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
            </script>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <form id="carForm" method="POST" action="" enctype="multipart/form-data">
            <div class="flex flex-col gap-5">

                <div class="relative flex justify-center mb-6">
                    <label for="item_image" class="cursor-pointer">
                        <img id="profile-img" src="<?= htmlspecialchars($item_image) ?: 'default-avatar.jpg' ?>"
                            alt="Item Image" class="h-32 w-32 rounded-full border-2 border-gray-300 object-cover">
                        <input type="file" id="item_image" name="item_image" class="hidden"
                            onchange="previewImage(event)" />
                    </label>
                </div>

                <div class="mb-4">
                    <label for="item_name" class="block text-sm font-medium text-gray-700">Item Name</label>
                    <input type="text"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 <?= !empty($item_name_error) ? 'border-red-500' : '' ?>"
                        id="item_name" name="item_name" value="<?= htmlspecialchars($item_name) ?>">

                    <?php if (!empty($item_name_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($item_name_error) ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-4">
                    <label for="item_details" class="block text-sm font-medium text-gray-700">Item Details</label>
                    <textarea id="item_details" name="item_details"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"><?= htmlspecialchars($item_details) ?></textarea>
                </div>

                <div class="mb-4">
                    <label for="quantity" class="block text-sm font-medium text-gray-700">Quantity / KG</label>
                    <input type="text"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 <?= !empty($quantity_error) ? 'border-red-500' : '' ?>"
                        id="quantity" name="quantity" value="<?= htmlspecialchars($quantity) ?>">

                    <?php if (!empty($quantity_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($quantity_error) ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-4">
                    <label for="price" class="block text-sm font-medium text-gray-700">Price / KG</label>
                    <input type="text"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 <?= !empty($price_error) ? 'border-red-500' : '' ?>"
                        id="price" name="price" value="<?= htmlspecialchars($price) ?>">

                    <?php if (!empty($price_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($price_error) ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-4">
                    <label for="item_category" class="block text-sm font-medium text-gray-700">Item Category</label>
                    <input type="text" disabled value="<?= htmlspecialchars($item_category) ?>"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500">
                </div>

                <div class="mb-4">
                    <label for="availability" class="block text-sm font-medium text-gray-700">Availability</label>
                    <input type="text" disabled value="<?= htmlspecialchars($availability) ?>"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500">
                </div>
            </div>

            <div class="mt-6">
                <button type="submit"
                    class="w-full md:w-auto px-6 py-3 text-white bg-blue-600 rounded-md shadow-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50">
                    Update Car
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function previewImage(event) {
        const file = event.target.files[0];
        const reader = new FileReader();

        reader.onload = function () {
            const profileImg = document.getElementById('profile-img');
            profileImg.src = reader.result;
        };

        if (file) {
            reader.readAsDataURL(file);
        }
    }
</script>

<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/footer.php';
?>