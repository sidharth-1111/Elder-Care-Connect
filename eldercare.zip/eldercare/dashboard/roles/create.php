<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/config.php';

$role_name_error = "";
$description_error = "";
$role_name = "";
$description = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role_name = $_POST['role_name'] ?? '';
    $description = $_POST['description'] ?? '';

    if (empty($role_name)) {
        $role_name_error = "Role name is required.";
    }

    if (empty($description)) {
        $description_error = "Description is required.";
    }

    if (empty($role_name_error) && empty($description_error)) {
        global $conn;
        $stmt = $conn->prepare("INSERT INTO roles (role_name, description) VALUES (?, ?)");
        $stmt->bind_param("ss", $role_name, $description);

        if ($stmt->execute()) {
            $_SESSION['message'] = "Role created successfully!";
            header("Location: " . $baseUrl . '/dashboard/roles/create.php');
            exit;
        } else {
            $message = "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}

include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/header.php';
?>

<div class="p-6 max-w-4xl mx-auto">
    <div class="bg-white border border-gray-100 shadow p-6 rounded-md">
        <h2 class="text-2xl font-semibold text-gray-800 mb-6">Create Role</h2>

        <?php if (!empty($_SESSION['message'])): ?>
            <script>
                // Show the toast message when the role is created successfully
                showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
            </script>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <form id="roleForm" method="POST" action="">
            <div class="flex flex-col gap-5">
                <div class="mb-4">
                    <label for="role_name" class="block text-sm font-medium text-gray-700">Role Name</label>
                    <input type="text"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-300 ease-in-out <?= !empty($role_name_error) ? 'border-red-500' : '' ?>"
                        id="role_name" name="role_name" value="<?= htmlspecialchars($role_name) ?>">

                    <?php if (!empty($role_name_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($role_name_error) ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-4">
                    <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                    <textarea id="description" name="description" rows="3"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-300 ease-in-out <?= !empty($description_error) ? 'border-red-500' : '' ?>"><?= htmlspecialchars($description) ?></textarea>

                    <?php if (!empty($description_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($description_error) ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="mt-6">
                <button type="submit"
                    class="w-full md:w-auto px-6 py-3 text-white bg-blue-600 rounded-md shadow-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50">
                    Create Role
                </button>
            </div>
        </form>
    </div>
</div>



<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/footer.php';
?>