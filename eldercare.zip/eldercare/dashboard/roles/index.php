<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/config.php';

function getRoles()
{
    global $conn;
    $sql = "SELECT * FROM roles";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

$roles = getRoles();

if (isset($_POST['delete_role']) && isset($_POST['role_id'])) {
    $roleId = intval($_POST['role_id']);

    $sql = "DELETE FROM roles WHERE role_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $roleId);

    if ($stmt->execute()) {
        $stmt->close();
        $_SESSION['message'] = "Role deleted successfully!";
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        echo 'Error deleting role.';
    }
}

include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/header.php';
?>


<div class="p-6">
    <?php if (!empty($_SESSION['message'])): ?>
        <script>
            showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
        </script>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <div class="bg-white border border-gray-100 shadow-md shadow-black/5 p-6 rounded-md">
        <div class="flex justify-between mb-4 items-start">
            <div class="font-medium">Manage Roles</div>
            <div class="dropdown">
                <a href="create.php"
                    class="flex items-center text-[13px] py-1.5 px-4 text-white bg-blue-700  hover:bg-blue-600 rounded shadow">Create
                    Role</a>
            </div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full min-w-[540px] table-auto">
                <thead>
                    <tr>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            #</th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Role Name
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Description
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody class="text-sm text-gray-600">
                    <?php foreach ($roles as $index => $role) { ?>
                        <tr class="border-b border-gray-100 hover:bg-gray-50">
                            <td class="py-4 px-4 text-gray-500"><?php echo $index + 1; ?></td>
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($role['role_name']) ?></td>
                            <td class="py-4 px-4 text-gray-500">
                                <?php echo htmlspecialchars($role['description'] ?? 'N/A') ?>
                            </td>
                            <td class="py-4 px-4">
                                <div class="flex space-x-3">
                                    <a href="edit.php?id=<?php echo $role['role_id']; ?>"
                                        class="text-gray-600 hover:text-blue-500 transition duration-300">
                                        <i class="ri-edit-2-line text-lg"></i>
                                    </a>
                                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST"
                                        onsubmit="return confirm('Are you sure you want to delete this role?');">
                                        <input type="hidden" name="role_id" value="<?php echo $role['role_id']; ?>">
                                        <button type="submit" name="delete_role"
                                            class="text-gray-600 hover:text-red-500 transition duration-300">
                                            <i class="ri-delete-bin-2-line text-lg"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>

                </tbody>
            </table>
        </div>
    </div>
</div>


<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/footer.php';
?>