<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/config.php';

$car_name = "";
$car_model = "";
$car_image = "";
$price = "";
$driver_id = "";
$availability = 1; 
$car_name_error = "";
$car_model_error = "";
$price_error = "";
$driver_error = "";

function getDrivers()
{
    global $conn;
    $sql = "SELECT u.user_id, u.name
            FROM users u
            JOIN roles r ON u.role_id = r.role_id
            WHERE r.role_name = 'driver'";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

$drivers = getDrivers();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $car_name = $_POST['car_name'] ?? '';
    $car_model = $_POST['car_model'] ?? '';
    $car_image = $_POST['car_image'] ?? '';
    $price = $_POST['price'] ?? '';
    $driver_id = $_POST['driver_id'] ?? '';
    $availability = $_POST['availability'] ?? 1;
    $car_image = $_FILES['car_image']['name'] ?? '';
    
    if (empty($car_name)) {
        $car_name_error = "Car name is required.";
    }

    if (empty($car_model)) {
        $car_model_error = "Car model is required.";
    }

    if (empty($price)) {
        $price_error = "Price is required.";
    } elseif (!is_numeric($price)) {
        $price_error = "Price must be a valid number.";
    }

    if (empty($driver_id)) {
        $driver_error = "Driver is required.";
    }

    if (empty($car_name_error) && empty($car_model_error) && empty($price_error) && empty($driver_error)) {
        global $conn;

        $car_image_path = '';
        if (!empty($car_image)) {
            $target_dir = $_SERVER['DOCUMENT_ROOT'] . '/eldercare/uploads/cars/';
            $target_file = $target_dir . basename($car_image);
            move_uploaded_file($_FILES['car_image']['tmp_name'], $target_file);
            $car_image_path = '/eldercare/uploads/cars/' . basename($car_image);
        }

        $stmt = $conn->prepare("INSERT INTO cars (car_name, car_model, car_image, price, driver_id, availability) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssdis", $car_name, $car_model, $car_image_path, $price, $driver_id, $availability);

        if ($stmt->execute()) {
            $_SESSION['message'] = "Car added successfully!";
            header("Location: " . $baseUrl . '/dashboard/cars/create.php');
            exit;
        } else {
            $message = "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}

include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/header.php';
?>

<div class="p-6 max-w-4xl mx-auto">
    <div class="bg-white border border-gray-100 shadow p-6 rounded-md">
        <h2 class="text-2xl font-semibold text-gray-800 mb-6">Add New Car</h2>

        <?php if (!empty($_SESSION['message'])): ?>
            <script>
                showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
            </script>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <form id="carForm" method="POST" action="" enctype="multipart/form-data">
            <div class="flex flex-col gap-5">
                <div class="mb-4">
                    <label for="car_name" class="block text-sm font-medium text-gray-700">Car Name</label>
                    <input type="text"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 <?= !empty($car_name_error) ? 'border-red-500' : '' ?>"
                        id="car_name" name="car_name" value="<?= htmlspecialchars($car_name) ?>">

                    <?php if (!empty($car_name_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($car_name_error) ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-4">
                    <label for="car_model" class="block text-sm font-medium text-gray-700">Car Model</label>
                    <input type="text"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 <?= !empty($car_model_error) ? 'border-red-500' : '' ?>"
                        id="car_model" name="car_model" value="<?= htmlspecialchars($car_model) ?>">

                    <?php if (!empty($car_model_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($car_model_error) ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-4">
                    <label for="car_image" class="block text-sm font-medium text-gray-700">Car Image</label>
                    <input type="file" id="car_image" name="car_image"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500">
                </div>

                <div class="mb-4">
                    <label for="price" class="block text-sm font-medium text-gray-700">Price / KL</label>
                    <input type="text"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 <?= !empty($price_error) ? 'border-red-500' : '' ?>"
                        id="price" name="price" value="<?= htmlspecialchars($price) ?>">

                    <?php if (!empty($price_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($price_error) ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-4">
                    <label for="driver_id" class="block text-sm font-medium text-gray-700">Driver</label>
                    <select id="driver_id" name="driver_id"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 <?= !empty($driver_error) ? 'border-red-500' : '' ?>">
                        <option value="">Select Driver</option>
                        <?php
                        foreach ($drivers as $driver): ?>
                            <option value="<?= $driver['user_id'] ?>" <?= $driver_id == $driver['user_id'] ? 'selected' : '' ?>><?= htmlspecialchars($driver['name']) ?></option>
                        <?php endforeach; ?>
                    </select>

                    <?php if (!empty($driver_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($driver_error) ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-4">
                    <label for="availability" class="block text-sm font-medium text-gray-700">Availability</label>
                    <select id="availability" name="availability"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500">
                        <option value="1" <?= $availability == 1 ? 'selected' : '' ?>>Available</option>
                        <option value="0" <?= $availability == 0 ? 'selected' : '' ?>>Not Available</option>
                    </select>
                </div>
            </div>

            <div class="mt-6">
                <button type="submit"
                    class="w-full md:w-auto px-6 py-3 text-white bg-blue-600 rounded-md shadow-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50">
                    Add Car
                </button>
            </div>
        </form>
    </div>
</div>

<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/footer.php';
?>
