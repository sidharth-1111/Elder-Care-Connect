<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/config.php';

$car_name = "";
$car_model = "";
$car_image = "";
$price = "";
$driver_id = "";
$availability = 1;
$car_name_error = "";
$car_model_error = "";
$price_error = "";
$driver_error = "";
$car_id = $_GET['id'] ?? null;

if ($car_id) {
    $sql = "SELECT 
            cars.car_id,
            cars.car_name,
            cars.car_model,
            cars.car_image,
            cars.price,
            cars.driver_id,
            cars.availability,
            users.name AS driver_name,
            users.user_id AS driver_id
        FROM 
            cars
        JOIN 
            users ON cars.driver_id = users.user_id
        WHERE cars.car_id = ?;";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $car_id);
    $stmt->execute();
    $car = $stmt->get_result()->fetch_assoc();

    if (!$car) {
        $_SESSION['message'] = "Car not found.";
        header("Location: " . $baseUrl . '/dashboard/cars/');
        exit;
    }

    $car_name = $car['car_name'];
    $car_model = $car['car_model'];
    $car_image = $car['car_image'];
    $price = $car['price'];
    $driver_id = $car['driver_id'];
    $driver_name = $car['driver_name'];
    $availability = $car['availability'] == 1 ? "Available" : "Not Available";
}

function getAllDrivers()
{
    global $conn;
    $sql = "SELECT * FROM users WHERE role_id = 4;";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $car_name = $_POST['car_name'] ?? '';
    $car_model = $_POST['car_model'] ?? '';
    $price = $_POST['price'] ?? '';
    $driver_id = $_POST['driver_id'] ?? '';
    $availability = $_POST['availability'] ?? 1;
    $new_car_image = $_FILES['car_image']['name'] ?? '';

    if (empty($car_name)) {
        $car_name_error = "Car name is required.";
    }

    if (empty($car_model)) {
        $car_model_error = "Car model is required.";
    }

    if (empty($price)) {
        $price_error = "Price is required.";
    } elseif (!is_numeric($price)) {
        $price_error = "Price must be a valid number.";
    }

    if (empty($driver_id)) {
        $driver_error = "Driver selection is required.";
    }

    if (empty($car_name_error) && empty($car_model_error) && empty($price_error) && empty($driver_error)) {
        global $conn;

        $car_image_path = $car_image;
        if (!empty($new_car_image)) {
            $target_dir = $_SERVER['DOCUMENT_ROOT'] . '/eldercare/uploads/cars/';
            $target_file = $target_dir . basename($new_car_image);
            move_uploaded_file($_FILES['car_image']['tmp_name'], $target_file);
            $car_image_path = '/eldercare/uploads/cars/' . basename($new_car_image);
        }

        $stmt = $conn->prepare("UPDATE cars SET car_name = ?, car_model = ?, car_image = ?, price = ?, driver_id = ?, availability = ? WHERE car_id = ?");
        $stmt->bind_param("sssdisi", $car_name, $car_model, $car_image_path, $price, $driver_id, $availability, $car_id);

        if ($stmt->execute()) {
            $_SESSION['message'] = "Car updated successfully!";
            header("Location: " . $baseUrl . '/dashboard/cars/');
            exit;
        } else {
            $message = "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}

$drivers = getAllDrivers();

include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/header.php';
?>

<div class="p-6 max-w-4xl mx-auto">
    <div class="bg-white border border-gray-100 shadow p-6 rounded-md">
        <h2 class="text-2xl font-semibold text-gray-800 mb-6">Update Car</h2>

        <?php if (!empty($_SESSION['message'])): ?>
            <script>
                showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
            </script>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <form id="carForm" method="POST" action="" enctype="multipart/form-data">
            <div class="flex flex-col gap-5">

                <div class="relative flex justify-center mb-6">
                    <label for="car_image" class="cursor-pointer">
                        <img id="profile-img" src="<?= htmlspecialchars($car_image) ?: 'default-avatar.jpg' ?>" 
                             alt="Car Image" class="h-32 w-32 rounded-full border-2 border-gray-300 object-cover">
                        <input type="file" id="car_image" name="car_image" class="hidden" onchange="previewImage(event)" />
                    </label>
                </div>

                <div class="mb-4">
                    <label for="car_name" class="block text-sm font-medium text-gray-700">Car Name</label>
                    <input type="text"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 <?= !empty($car_name_error) ? 'border-red-500' : '' ?>"
                        id="car_name" name="car_name" value="<?= htmlspecialchars($car_name) ?>">

                    <?php if (!empty($car_name_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($car_name_error) ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-4">
                    <label for="car_model" class="block text-sm font-medium text-gray-700">Car Model</label>
                    <input type="text"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 <?= !empty($car_model_error) ? 'border-red-500' : '' ?>"
                        id="car_model" name="car_model" value="<?= htmlspecialchars($car_model) ?>">

                    <?php if (!empty($car_model_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($car_model_error) ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-4">
                    <label for="price" class="block text-sm font-medium text-gray-700">Price / KL</label>
                    <input type="text"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 <?= !empty($price_error) ? 'border-red-500' : '' ?>"
                        id="price" name="price" value="<?= htmlspecialchars($price) ?>">

                    <?php if (!empty($price_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($price_error) ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-4">
                    <label for="driver_id" class="block text-sm font-medium text-gray-700">Driver</label>
                    <select id="driver_id" name="driver_id"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 <?= !empty($driver_error) ? 'border-red-500' : '' ?>">
                        <option value="">Select a Driver</option>
                        <?php
                        foreach ($drivers as $driver): ?>
                            <option value="<?= $driver['user_id'] ?>" <?= $driver_id == $driver['user_id'] ? 'selected' : '' ?>><?= htmlspecialchars($driver['name']) ?></option>
                        <?php endforeach; ?>
                    </select>

                    <?php if (!empty($driver_error)): ?>
                        <p class="mt-2 text-sm text-red-600"><?= htmlspecialchars($driver_error) ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-4">
                    <label for="availability" class="block text-sm font-medium text-gray-700">Availability</label>
                    <input type="text" disabled value="<?= $availability ?>"
                        class="mt-1 py-2 px-3 block w-full border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500">
                </div>
            </div>

            <div class="mt-6">
                <button type="submit"
                    class="w-full md:w-auto px-6 py-3 text-white bg-blue-600 rounded-md shadow-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50">
                    Update Item
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function previewImage(event) {
        const file = event.target.files[0];
        const reader = new FileReader();

        reader.onload = function () {
            const profileImg = document.getElementById('profile-img');
            profileImg.src = reader.result;
        };

        if (file) {
            reader.readAsDataURL(file);
        }
    }
</script>

<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/footer.php';
?>
