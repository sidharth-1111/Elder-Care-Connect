<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/config.php';

function getCarsWithDriver()
{
    global $conn;
    $sql = "SELECT cars.*, users.name AS driver_name 
            FROM cars 
            JOIN users ON cars.driver_id = users.user_id";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

$cars = getCarsWithDriver();

if (isset($_POST['delete_car']) && isset($_POST['car_id'])) {
    $carId = intval($_POST['car_id']);
    $sql = "DELETE FROM cars WHERE car_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $carId);

    if ($stmt->execute()) {
        $stmt->close();
        $_SESSION['message'] = "Car deleted successfully!";
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        echo 'Error deleting user.';
    }
}
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/header.php';
?>


<div class="p-6">
    <?php if (!empty($_SESSION['message'])): ?>
        <script>
            showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
        </script>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>
    <div class="bg-white border border-gray-100 shadow-md shadow-black/5 p-6 rounded-md">
        <div class="flex justify-between mb-4 items-start">
            <div class="font-medium">Manage Cars</div>
            <div class="dropdown">
                <a href="create.php"
                    class="flex items-center text-[13px] py-1.5 px-4 text-white bg-blue-700  hover:bg-blue-600 rounded shadow">Create Car</a>
            </div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full min-w-[540px] table-auto">
                <thead>
                    <tr>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                           Car Picture
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Car Name
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Car Model
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Price / KL
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Driver
                        </th>
                        <th
                            class="text-xs uppercase tracking-wider font-semibold text-gray-500 py-3 px-4 bg-gray-100 text-left">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody class="text-sm text-gray-600">
                    <?php foreach ($cars as $car) { ?>
                        <tr class="border-b border-gray-100 hover:bg-gray-50">
                            <td class="py-4 px-4 flex items-center space-x-3">
                                <img src="<?php echo $car['car_image'] ?> " alt="" class="w-8 h-8 rounded-full object-cover">
                            </td>
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($car['car_name']) ?></td>
                            <td class="py-4 px-4 text-gray-500"><?php echo htmlspecialchars($car['car_model'] ?? 'N/A') ?>
                            </td>
                            <td class="py-4 px-4 text-gray-500"><?php echo $car['price'] ?></td>
                            <td class="py-4 px-4 text-gray-500"><?php echo $car['driver_name'] ?></td>
                            <td class="py-4 px-4">
                                <div class="flex space-x-3">
                                    <a href="edit.php?id=<?php echo $car['car_id']; ?>"
                                        class="text-gray-600 hover:text-blue-500 transition duration-300">
                                        <i class="ri-edit-2-line text-lg"></i>
                                    </a>
                                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST"
                                        onsubmit="return confirm('Are you sure you want to delete this car?');">
                                        <input type="hidden" name="car_id" value="<?php echo $car['car_id']; ?>">
                                        <button type="submit" name="delete_car"
                                            class="text-gray-600 hover:text-red-500 transition duration-300">
                                            <i class="ri-delete-bin-2-line text-lg"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/common/footer.php';
?>