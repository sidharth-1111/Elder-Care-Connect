<?php
$baseUrl = "http://localhost/eldercare";
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/config.php';

$name_error = "";
$email_error = "";
$password_error = "";
$conform_password_error = "";
$name = "";
$email = "";
$password = "";
$role_id = 2;
$conform_password = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $conform_password = $_POST['conform_password'] ?? '';


    if (empty($name)) {
        $name_error = "Name is required.";
    }

    if (empty($email)) {
        $email_error = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $email_error = "Invalid email format.";
    }

    if (empty($password)) {
        $password_error = "Password is required.";
    }

    if (empty($conform_password)) {
        $conform_password_error = "Confirm password is required.";
    } elseif ($password !== $conform_password) {
        $conform_password_error = "Password doesn't match.";
    }

    if (empty($name_error) && empty($email_error) && empty($password_error) && empty($conform_password_error)) {
        global $conn;

        $role_query = $conn->prepare("SELECT * FROM roles WHERE role_id = ?");
        $role_query->bind_param("i", $role_id);
        $role_query->execute();
        $role_result = $role_query->get_result();

        if ($role_result->num_rows > 0) {
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("INSERT INTO users (name, email, password, role_id) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("sssi", $name, $email, $hashed_password, $role_id);

            if ($stmt->execute()) {
                $_SESSION['message'] = "Successfully Registered! Please Login";
                header("Location: " . $baseUrl . '/login.php');
                exit;
            } else {
                $message = "Error: " . $stmt->error;
            }

            $stmt->close();
        } else {
            $role_error = "Invalid role selected.";
        }
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elder Care</title>

    <link rel="shortcut icon" type="image/png" href="assets/img/favicon.png">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/components/logins/login-9/assets/css/login-9.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/meanmenu.min.css">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="stylesheet" href="assets/css/eldercare.css">
    <script src="<?php echo $baseUrl; ?>/assets/js/toast.js"></script>
</head>

<body style="background-color: #f5f5f5;">
    <div class="max-w-lg mx-auto">
        <div class="d-flex align-items-center justify-content-center" style="height: 100vh;">
            <div class="login-wrap p-5 p-md-5 shadow-sm" style="background-color: #ffffff; width: 500px;">
                <div class="d-flex mb-3">
                    <div class="w-100">
                        <h4  class="text-center">Elder Care</h4>
                        <h5 class="text-center font-weight-normal" style="color: #3b82f6;">Create your account</h5>
                    </div>
                </div>
                <form action="register.php" class="signin-form" method="POST">
                    <?php if (!empty($error_msg)): ?>
                        <p class="mt-2 text-danger text-center"><?= htmlspecialchars($error_msg) ?></p>
                    <?php endif; ?>

                    <div class="form-group mb-3">
                        <label class="label" for="name">Name</label>
                        <input type="text" name="name" id="name" value="<?= htmlspecialchars($name) ?>" class="form-control <?php echo !empty($name_error) ? 'is-invalid' : '' ?>" placeholder="Name">
                        <?php if (!empty($name_error)): ?>
                            <div class="invalid-feedback"><?= htmlspecialchars($name_error) ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group mb-3">
                        <label class="label" for="email">Email</label>
                        <input type="email" name="email" id="email" value="<?= htmlspecialchars($email) ?>" class="form-control <?php echo !empty($email_error) ? 'is-invalid' : '' ?>" placeholder="Email" required="">
                        <?php if (!empty($email_error)): ?>
                            <div class="invalid-feedback"><?= htmlspecialchars($email_error) ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group mb-3">
                        <label class="label" for="password">Password</label>
                        <input type="password" name="password" id="password" class="form-control <?= !empty($password_error) ? 'is-invalid' : '' ?>"
                            placeholder="Password">
                        <?php if (!empty($password_error)): ?>
                            <div class="invalid-feedback"><?= htmlspecialchars($password_error) ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group mb-3">
                        <label for="conform_password" class="label">Confirm Password</label>
                        <input type="password" id="conform_password" name="conform_password" class="form-control <?= !empty($conform_password_error) ? 'is-invalid' : '' ?>">
                        <?php if (!empty($conform_password_error)): ?>
                            <p class="invalid-feedback"><?= htmlspecialchars($conform_password_error) ?></p>
                        <?php endif; ?>
                    </div>


                    <div class="form-group">
                        <button type="submit" class="form-control btn btn-primary rounded submit px-3">Sign Up</button>
                    </div>
                    <div class="form-group d-md-flex">
                       
                    </div>
                </form>
                <p class="text-center">Already a member? <a href="/eldercare/login.php">Sign In</a></p>
            </div>
        </div>
    </div>

</body>

</html>
