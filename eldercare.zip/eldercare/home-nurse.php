<?php
session_start();
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

function getNurses()
{
    global $conn;
    $sql = "SELECT * FROM users WHERE role_id = 6";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

$nurses = getNurses();

function getUser($userId)
{
    global $conn;
    $sql = "SELECT * FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

$user = getUser($_SESSION['user_id']);

if (isset($_POST['book_now']) && isset($_POST['nurse_id'])) {
    $nurse_id = $_POST['nurse_id'];
    $customer_id = $_SESSION['user_id'];
    $booking_date = $_POST['booking_date'];
    $address = $_POST['address'];
    $status = 'pending';
    $errors = [];

    if (empty($booking_date)) {
        $errors[] = 'Booking date is required.';
    }
    if (empty($address)) {
        $errors[] = 'Address is required.';
    }
    if (empty($errors)) {
        $sql = "INSERT INTO home_nurse_bookings (customer_id, home_nurse_id, booking_status, booking_date, service_address)
                VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        
        if ($stmt) {
            $stmt->bind_param("iisss", $customer_id, $nurse_id, $status, $booking_date, $address);
            
            if ($stmt->execute()) {
                $_SESSION['success_message'] = "Successfully booked!";
                header("Location: home-nurse.php");
                exit;
            } else {
                $errors[] = 'Failed to book the appointment: ' . $stmt->error;
            }
        } else {
            $errors[] = 'Failed to prepare the statement: ' . $conn->error;
        }
    }

    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo "<p>$error</p>";
        }
    }
}



include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/header.php';
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/navigation.php';
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/cart-sidebar.php';
?>


<div class="container mb-150 mt-150">
    <h3 class="text-center mb-80">Book a Home Nurse</h3>

    <?php if (!empty($_SESSION['success_message'])): ?>
        <div class="alert alert-success">
            <?= htmlspecialchars($_SESSION['success_message']) ?>
        </div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>

    <!-- Display errors if any -->
    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error) ?></li>
                <?php endforeach ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group" id="doctorInfo">
            <div class="row" id="doctorCards">
                <?php if (!empty($nurses)): ?>
                    <?php foreach ($nurses as $nurse): ?>
                        <div class="col-md-4 mb-4">
                            <div class="card">
                                <img class="card-img-top" src="<?= htmlspecialchars($nurse['profile_picture']) ?>" alt="Picture">
                                <div class="card-body">
                                    <h5 class="card-title"><?= htmlspecialchars($nurse['name']) ?></h5>
                                    <p class="card-text">
                                        <strong>Email:</strong> <?= htmlspecialchars($nurse['email']) ?><br>
                                        <strong>Phone:</strong> <?= htmlspecialchars($nurse['phone_number']) ?><br>
                                        <strong>Address:</strong> <?= htmlspecialchars($nurse['address']) ?>
                                    </p>
                                    <button type="button" class="btn btn-primary bookDoctorBtn"
                                        data-doctor-name="<?= htmlspecialchars($nurse['name']) ?>"
                                        data-doctor-id="<?= htmlspecialchars($nurse['user_id']) ?>">Select</button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group" id="edlbooking" style="display: none;">
            <input type="hidden" name="nurse_id" id="selectedDoctorId">
            
            <h5 class="mt-4">Booking Information</h5>
            <div class="form-group">
                <label for="selectedDoctor">Selected Nurse</label>
                <input type="text" class="form-control" id="selectedDoctor" readonly name="nurse">
            </div>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="patientName">Your Name</label>
                    <input type="text" class="form-control" id="patientName" value="<?= htmlspecialchars($_SESSION['name'] ?? '') ?>" readonly name="patient_name">
                </div>
                <div class="form-group col-md-6">
                    <label for="patientContact">Contact Information</label>
                    <input type="text" class="form-control" id="patientContact" value="<?= htmlspecialchars($_SESSION['phone'] ?? '') ?>"  name="patient_contact" required>
                </div>
            </div>

            <div class="form-row">                
                <div class="form-group col-md-6">
                    <label for="appointmentTime">Address</label>
                    <textarea name="address" id="address"  class="form-control"><?= htmlspecialchars($user['address'] ?? '') ?></textarea>
                </div>
                <div class="form-group col-md-6">
                    <label for="appointmentDate">Booking Date</label>
                    <input type="date" class="form-control" id="appointmentDate" name="booking_date" required>
                </div>
            </div>
        </div>

        <button type="submit" name="book_now" class="btn btn-primary btn-block mt-4" id="submitButton">Book Now</button>
    </form>

</div>

<script>
    document.querySelectorAll('.bookDoctorBtn').forEach(function (button) {
        button.addEventListener('click', function () {
            const doctorName = this.getAttribute('data-doctor-name');
            const doctorID = this.getAttribute('data-doctor-id');
            document.getElementById('selectedDoctor').value = doctorName;
            document.getElementById('selectedDoctorId').value = doctorID;
            document.getElementById('edlbooking').style.display = 'block';
        });
    });
</script>

<?php include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/footer.php'; ?>