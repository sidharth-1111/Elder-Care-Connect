<?php
session_start();
$baseUrl = "http://localhost/eldercare";
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/db.php';
?>