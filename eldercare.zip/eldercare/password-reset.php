<?php
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/config.php';

$email_error = "";
$email = "";
$error_msg = "";


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';

    if (empty($email)) {
        $email_error = "Email is required.";
    }

}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elder Care</title>

    <link rel="shortcut icon" type="image/png" href="assets/img/favicon.png">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/components/logins/login-9/assets/css/login-9.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/meanmenu.min.css">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="stylesheet" href="assets/css/eldercare.css">
    <script src="<?php echo $baseUrl; ?>/assets/js/toast.js"></script>

    <style>
        .hidden {
            display: none !important;
        }

        .eld {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            position: absolute;
            top: 10px;
        }

        .mt-120 {
            margin-top: 120px;
        }
        
    </style>
</head>

<body style="background-color: #f5f5f5;">
    <div id="eltoast" class="hidden eld">
        <div id="toastClass" class="alert alert-success w-50" role="alert" style="z-index: 99999">
            <strong id="eltoastmessage">Holy guacamole!</strong>
            <button type="button" class="close" id="toast-close-btn">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>

    <?php if (!empty($_SESSION['message'])): ?>
        <script>
            showToast('<?php echo htmlspecialchars($_SESSION['message']) ?>');
        </script>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <div class="max-w-lg mx-auto">
        <div class="d-flex align-items-center justify-content-center" style="height: 100vh;">
            <div class="login-wrap p-5 p-md-5 shadow-sm" style="background-color: #ffffff; width: 500px;">
                <div class="d-flex">
                    <div class="w-100">
                        <h5 class="font-weight-normal mb-4 text-center">Reset your password</h5>
                    </div>
                </div>
                <form action="password-reset.php" class="signin-form" method="POST">
                    <?php if (!empty($error_msg)): ?>
                        <p class="mt-2 text-danger text-center"><?= htmlspecialchars($error_msg) ?></p>
                    <?php endif; ?>
                    <div class="form-group mb-3">
                        <label class="label" for="name">Email</label>
                        <input type="email" name="email" value="<?= htmlspecialchars($email) ?>"
                            class="form-control <?php echo !empty($email_error) ? 'is-invalid' : '' ?>" id="email"
                            placeholder="Email" required="">
                        <?php if (!empty($email_error)): ?>
                            <div class="invalid-feedback"><?= htmlspecialchars($email_error) ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="form-control btn btn-primary rounded submit px-3">Reset Password</button>
                    </div>
                </form>
                <p class="text-center"> <a data-toggle="tab" href="/eldercare/login.php">Sign In</a></p>
            </div>
        </div>
    </div>

</body>

</html>