<?php
session_start();
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/config/db.php';

$hospital_id = "";
$doctorDetails = [];
$date="";

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

function getHospitals()
{
    global $conn;
    $sql = "SELECT * FROM hospitals";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

function getDoctorHospitals($hospital_id)
{
    global $conn;
    $sql = "SELECT
                h.hospital_id,
                h.name AS hospital_name,
                h.address AS hospital_address,
                h.description AS hospital_description,
                d.user_id AS doctor_id,
                d.name AS doctor_name,
                d.email AS doctor_email,
                d.phone_number AS doctor_phone_number,
                d.address AS doctor_address,
                d.profile_picture AS doctor_profile_picture
            FROM
                hospitals h
            JOIN
                doctor_hospitals dh ON h.hospital_id = dh.hospital_id
            JOIN
                users d ON dh.doctor_id = d.user_id
            WHERE
                h.hospital_id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $hospital_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['hospital_id'])) {
    $hospital_id = (int) $_POST['hospital_id'];
    $doctorDetails = getDoctorHospitals($hospital_id);
}

if (isset($_POST['book_appointment']) && isset($_POST['doctor_id'])) {
    $doctor_id = $_POST['doctor_id'];
    $patient_id = $_SESSION['user_id'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];
    $patient_contact = $_POST['patient_contact'];

    $errors = [];
    if (empty($appointment_date)) {
        $errors[] = 'Appointment date is required.';
    }
    if (empty($appointment_time)) {
        $errors[] = 'Appointment time is required.';
    }
    if (empty($patient_contact)) {
        $errors[] = 'Contact information is required.';
    }
    function date($date){
        if{
            
        }
    }

    if (empty($errors)) {
        $sql = "INSERT INTO appointments (customer_id, doctor_id, hospital_id, appointment_date, appointment_time, status)
                VALUES (?, ?, ?, ?, ?, 'scheduled')";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiiss", $patient_id, $doctor_id, $hospital_id, $appointment_date, $appointment_time);

        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Appointment successfully booked!";
            header("Location: appoinment.php");
            exit;
        } else {
            $errors[] = 'Failed to book the appointment. Please try again later.';
        }
    }
}

$hospitals = getHospitals();

include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/header.php';
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/navigation.php';
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/cart-sidebar.php';
?>


<div class="container mb-150 mt-150">
    <h1 class="text-center mb-80">Book a Doctor Appointment</h1>

    <?php if (!empty($_SESSION['success_message'])): ?>
        <div class="alert alert-success">
            <?= htmlspecialchars($_SESSION['success_message']) ?>
        </div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error) ?></li>
                <?php endforeach ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" id="bookingForm">
    <div class="form-group">
            <label for="hospitalSelect">Select Hospital</label>
            <select name="hospital_id" id="hospitals" onchange="this.form.submit()">
                <option value="">Select a hospital</option>
                <?php foreach ($hospitals as $hospital): ?>
                    <option value="<?= $hospital['hospital_id'] ?>" <?= isset($_POST['hospital_id']) && $_POST['hospital_id'] == $hospital['hospital_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($hospital['name']) ?>
                    </option>
                <?php endforeach ?>
            </select>
        </div>
    </form>

    <!-- Booking Form -->
    <form method="POST">
        <div class="form-group" id="doctorInfo">
            <h5 class="mt-4">Doctor Details</h5>
            <div class="row" id="doctorCards">
                <?php if (!empty($doctorDetails)): ?>
                    <?php foreach ($doctorDetails as $doctor): ?>
                        <div class="col-md-4 mb-4">
                            <div class="card">
                                <img class="card-img-top" src="<?= htmlspecialchars($doctor['doctor_profile_picture']) ?>" alt="Doctor's Picture">
                                <div class="card-body">
                                    <h5 class="card-title"><?= htmlspecialchars($doctor['doctor_name']) ?></h5>
                                    <p class="card-text">
                                        <strong>Email:</strong> <?= htmlspecialchars($doctor['doctor_email']) ?><br>
                                        <strong>Phone:</strong> <?= htmlspecialchars($doctor['doctor_phone_number']) ?><br>
                                        <strong>Address:</strong> <?= htmlspecialchars($doctor['doctor_address']) ?>
                                    </p>
                                    <button type="button" class="btn btn-primary bookDoctorBtn"
                                        data-doctor-name="<?= htmlspecialchars($doctor['doctor_name']) ?>"
                                        data-doctor-id="<?= htmlspecialchars($doctor['doctor_id']) ?>">Book Appointment</button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group" id="edlbooking" style="display: none;">
            <input type="hidden" name="doctor_id" id="selectedDoctorId">
            <input type="hidden" value="<?= htmlspecialchars($hospital_id) ?>" name="hospital_id">
            <input type="hidden" name="patient_id" value="<?= $_SESSION['user_id'] ?>">
            
            <h5 class="mt-4">Booking Information</h5>
            <div class="form-group">
                <label for="selectedDoctor">Selected Doctor</label>
                <input type="text" class="form-control" id="selectedDoctor" readonly name="doctor">
            </div>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="patientName">Your Name</label>
                    <input type="text" class="form-control" id="patientName" value="<?= htmlspecialchars($_SESSION['name'] ?? '') ?>" readonly name="patient_name">
                </div>
                <div class="form-group col-md-6">
                    <label for="patientContact">Contact Information</label>
                    <input type="text" class="form-control" id="patientContact" value="<?= htmlspecialchars($_SESSION['phone'] ?? '') ?>"  name="patient_contact" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="appointmentDate">Appointment Date</label>
                    <input type="date" class="form-control" id="appointmentDate" name="appointment_date" required>
                </div>
                <div class="form-group col-md-6">
                    <label for="appointmentTime">Appointment Time</label>
                    <input type="time" class="form-control" id="appointmentTime" name="appointment_time" required>
                </div>
            </div>
        </div>

        <button type="submit" name="book_appointment" class="btn btn-primary btn-block mt-4" id="submitButton">Book Appointment</button>
    </form>
</div>

<script>
    document.querySelectorAll('.bookDoctorBtn').forEach(function (button) {
        button.addEventListener('click', function () {
            const doctorName = this.getAttribute('data-doctor-name');
            const doctorID = this.getAttribute('data-doctor-id');
            document.getElementById('selectedDoctor').value = doctorName;
            document.getElementById('selectedDoctorId').value = doctorID;
            document.getElementById('edlbooking').style.display = 'block';
        });
    });
</script>

<?php include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/footer.php'; ?>
