function showToast(message) { 
    var toast = document.getElementById("eltoast");
    var toastMessage = document.getElementById("eltoastmessage");
    toastMessage.textContent = message;
    toast.classList.remove("hidden");

    setTimeout(function () {
        toast.classList.add("hidden");
    }, 3000);

    var closeButton = document.getElementById("toast-close-btn");
    closeButton.addEventListener("click", function () {
        toast.classList.add("hidden");
    });
}
