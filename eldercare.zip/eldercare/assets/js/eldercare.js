// Close button click handler
document.getElementById('close-cart-sidebar').addEventListener('click', function () {
    var sidebar = document.getElementById('cart-sidebar');
    sidebar.classList.add('d-none'); // Hide the sidebar by adding the d-none class
});

function openCartSidebar() {
    var sidebar = document.getElementById('cart-sidebar');
    sidebar.classList.remove('d-none'); // Show the sidebar by removing the d-none class
}

//Modal for car booking
$('#bookingModal').on('show.bs.modal', function (event) {
    console.log(event);
    var button = $(event.relatedTarget); 
    var carName = button.data('carname');
    var price = button.data('price');
    var carId = button.data('carid');
    var customerId = button.data('customerid');
    var driverName = button.data('drivername');
    var driverId = button.data('driverid');

    var modal = $(this);
    modal.find('.modal-title').text('Book ' + carName);
    modal.find('#car_id').val(carId);
    modal.find('#pickup_location').val('');
    modal.find('#pickup_time').val('');
    modal.find('#dropoff_location').val('');
    modal.find('#customer_id').val(customerId);
    modal.find('#driver_id').val(driverId);
    modal.find('#driver_name').val(driverName);
});