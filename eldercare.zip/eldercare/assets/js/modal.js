// modal.js
function showModal(message, onConfirmCallback, onCancelCallback) {
    const modal = document.getElementById('dynamicModal');
    const messageElement = document.getElementById('modalMessage');
    const confirmBtn = document.getElementById('modalConfirmBtn');
    const cancelBtn = document.getElementById('modalCancelBtn');

    // Set the dynamic message
    messageElement.textContent = message;

    // Show the modal by removing the 'hidden' class
    modal.classList.remove('hidden');

    // Set the onConfirm callback
    confirmBtn.onclick = function () {
        onConfirmCallback(); // Execute the confirm action
        modal.classList.add('hidden'); // Hide the modal
    };

    // Set the onCancel callback
    cancelBtn.onclick = function () {
        onCancelCallback(); // Execute the cancel action
        modal.classList.add('hidden'); // Hide the modal
    };

    // Optional: Close the modal if the user clicks outside the modal
    window.onclick = function (event) {
        if (event.target === modal) {
            modal.classList.add('hidden'); // Hide the modal if clicked outside
        }
    };
}
