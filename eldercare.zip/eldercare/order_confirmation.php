<?php
session_start();
include 'config/db.php';

if (isset($_GET['order_id'])) {
    $orderId = $_GET['order_id'];

    $query = "SELECT * FROM delivery_orders WHERE order_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $orderId);
    $stmt->execute();
    $result = $stmt->get_result();
    $order = $result->fetch_assoc();

    $query = "SELECT * FROM delivery_items WHERE order_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $orderId);
    $stmt->execute();
    $itemsResult = $stmt->get_result();
 
    if (!$order) {
        $_SESSION['error'] = 'Order not found!';
        header('Location: index.php');
        exit();
    }
} else {
    $_SESSION['error'] = 'Invalid order!';
    header('Location: index.php');
    exit();
}

include 'includes/header.php';
include 'includes/navigation.php';
?>

<!-- Order Confirmation Page Content -->
<div class="order-confirmation mt-150 mb-150">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12">
                <h3>Order Confirmation</h3>
                <p>Thank you for your order! Your order ID is: #<?= $orderId ?></p>
                <p>Status: <?= ucfirst($order['order_status']) ?></p>
                <p>Delivery Address: <?= htmlspecialchars($order['delivery_address']) ?></p>
                <p>Expected Delivery: <?= $order['delivery_date'] ?></p>

                <h4>Order Items:</h4>
                <ul>
                    <?php while ($item = $itemsResult->fetch_assoc()) { ?>
                        <li>
                            Product ID: <?= $item['item_id'] ?>, 
                            Quantity: <?= $item['quantity'] ?>
                        </li>
                    <?php } ?>
                </ul>
            </div>
            <div class="col-lg-4">
                <div class="order-summary">
                    <h3>Order Summary</h3>
                    <table class="table">
                        <tr>
                            <td>Total Amount</td>
                            <td>₹<?= number_format($order['total_amount'], 2) ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
