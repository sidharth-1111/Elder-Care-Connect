<?php include 'head.php'; ?>

<div class="container mx-auto mt-150 mb-150">
    Doc
</div>




<?php include('footer.php') ?>