<?php
session_start();
include 'config/db.php';
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/header.php';
include $_SERVER['DOCUMENT_ROOT'] . '/eldercare/includes/navigation.php';
?>

<div class="hero-area hero-bg">
    <div class="container">
        <div class="row mt-0">
            <div class="col-lg-9 offset-lg-2 text-center">
                <div class="hero-text">
                    <div class="hero-text-tablecell">
                        <p class="subtitle">Caring Connections</p>
                        <h1>Trusted Care</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="list-section pt-80 pb-80">
    <div class="container">

        <div class="row">
            <div class="col-lg-4 col-md-6 mb-4 mb-lg-0">
                <div class="list-box d-flex align-items-center">
                    <div class="list-icon">
                        <i class="fas fa-shipping-fast"></i>
                    </div>
                    <div class="content">
                        <h3>Free Shipping</h3>
                        <p>When order over $75</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 mb-4 mb-lg-0">
                <div class="list-box d-flex align-items-center">
                    <div class="list-icon">
                        <i class="fas fa-phone-volume"></i>
                    </div>
                    <div class="content">
                        <h3>24/7 Support</h3>
                        <p>Get support all day</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6" id="services">
                <div class="list-box d-flex justify-content-start align-items-center">
                    <div class="list-icon">
                        <i class="fas fa-sync"></i>
                    </div>
                    <div class="content">
                        <h3>Refund</h3>
                        <p>Get refund within 3 days!</p>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


<div class="product-section mt-80 mb-150">
    <div class="container">
        <div>
            <div class="col-lg-8 offset-lg-2 text-center">
                <div class="section-title">
                    <h3><span class="orange-text">Our</span> Services</h3>
                    <p>"Your One-Stop Solution for Medical Care, Transport, and Shopping Needs!".</p>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row text-center justify-content-center">

                <div class="col-md-3">
                    <div class="service-card">
                        <i class="fas fa-hospital-alt"></i>
                        <h4>Medical Service</h4>
                        <p>Get professional medical consultation and services at your convenience.</p>
                        <a href="#" class="cart-btn" data-toggle="modal" data-target="#bookingModal">Book Now</a> 

                    </div>
                </div>


                <div class="col-md-3">
                    <div class="service-card">
                    <i class="fas fa-car-alt"></i>
                        <h4>Travel Service</h4>
                        <p>Explore new destinations with our customized travel packages and bookings.</p>
                        <a href="travel.php" class="cart-btn">Book Travel</a>
                    </div>
                </div>


                <div class="col-md-3">
                    <div class="service-card">
                        <i class="fas fa-shopping-cart"></i>
                        <h4>Shopping Service</h4>
                        <p>Get exclusive deals on products from top brands delivered to your doorsteps.</p>
                        <a href="shopping.php" class="cart-btn">Shop Now</a>
                    </div>
                </div>

            </div>
        </div>




    </div>
</div>

<section class="shop-banner">
    <div class="container text-center">
        <h3>December sale is on! <br> with big <span class="orange-text">Discount...</span></h3>
        <div class="sale-percent"><span>Sale! <br> Upto</span>50% <span>off</span></div>
        <a href="shop.html" class="cart-btn btn-lg">Shop Now</a>
    </div>
</section>






<div class="testimonail-section mt-150 mb-150">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 offset-lg-1 text-center">
                <div class="testimonial-sliders">
                    <div class="single-testimonial-slider">
                        <div class="client-avater">
                            <img src="assets/img/avaters/avatar1.png" alt="">
                        </div>
                        <div class="client-meta">
                            <h3>Saira Hakim </h3>
                            <p class="testimonial-body">
                                "The team at Elder Care Connect made a challenging time so much easier for our family.
                                Their personalized approach and consistent communication gave us peace of mind knowing
                                our dad was in excellent care."
                            </p>
                            <div class="last-icon">
                                <i class="fas fa-quote-right"></i>
                            </div>
                        </div>
                    </div>
                    <div class="single-testimonial-slider">
                        <div class="client-avater">
                            <img src="assets/img/avaters/avatar2.png" alt="">
                        </div>
                        <div class="client-meta">
                            <h3>David Niph </h3>
                            <p class="testimonial-body">
                                "I've been with Elder Care Connect for over a year, and the caregivers are like family
                                to me. They are professional, friendly, and always attentive to my needs. It’s
                                comforting to know I’m in such capable hands."
                            </p>
                            <div class="last-icon">
                                <i class="fas fa-quote-right"></i>
                            </div>
                        </div>
                    </div>
                    <div class="single-testimonial-slider">
                        <div class="client-avater">
                            <img src="assets/img/avaters/avatar3.png" alt="">
                        </div>
                        <div class="client-meta">
                            <h3> Mark J </h3>
                            <p class="testimonial-body">
                                "Elder Care Connect has been a godsend for our family. They provided compassionate and
                                reliable care for my mother, always going above and beyond to ensure her comfort and
                                well-being. I truly can’t thank them enough"
                            </p>
                            <div class="last-icon">
                                <i class="fas fa-quote-right"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="abt-section mb-150 pt-2 pb-2" style="background-color: #f5f5f5;" id="about">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-12">
                <div>
                    <img src="https://1thcm.com/wp-content/uploads/2022/08/happy-seniors-min.webp" alt="">

                </div>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="abt-text" style="text-align: left; padding-top: 0px;">
                    <p class="top-sub"></p>
                    <h2 style="line-height: 60px; "> <span class="orange-text">Empowering </span> Seniors with Care</h2>
                    <p>Welcome to Elder Care Connect, your trusted partner in providing essential support services for
                        seniors. We offer a comprehensive range of services designed to make life easier and more
                        comfortable, including medical assistance, safe and reliable transportation, shopping support,
                        and house maintenance. Our mission is to ensure that older adults can maintain their
                        independence, health, and peace of mind while staying connected to the care they deserve. At
                        Elder Care Connect, we are dedicated to enhancing the quality of life for seniors and their
                        families through compassionate, reliable, and professional service.</p>


                </div>
            </div>
        </div>
    </div>
</div>


<!-- Modal -->
<div id="bookingModal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Book a Service</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Please select an option:</p>
                <a href="appoinment.php" class="btn btn-primary">Book Appointment</a>
                <a href="home-nurse.php" class="btn btn-primary">Book Home Nurse</a>
            </div>
        </div>
    </div>
</div>


<?php
include 'includes/footer.php';
?>